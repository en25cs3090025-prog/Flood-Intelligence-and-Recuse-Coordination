import {
  ActivityLog,
  EmergencyNotification,
  Hospital,
  Incident,
  RescueTeam,
  RiverGaugeSensor,
  Shelter,
  UserProfile,
} from '../types';
import {
  DEMO_USERS,
  INITIAL_ACTIVITY_LOGS,
  INITIAL_HOSPITALS,
  INITIAL_INCIDENTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_RESCUE_TEAMS,
  INITIAL_RIVER_GAUGES,
  INITIAL_SHELTERS,
} from '../data/seedData';

const STORAGE_KEYS = {
  INCIDENTS: 'aquashield_incidents_v2',
  TEAMS: 'aquashield_teams_v2',
  SHELTERS: 'aquashield_shelters_v2',
  HOSPITALS: 'aquashield_hospitals_v2',
  GAUGES: 'aquashield_gauges_v2',
  NOTIFICATIONS: 'aquashield_notifications_v2',
  LOGS: 'aquashield_logs_v2',
  CURRENT_USER: 'aquashield_current_user_v2',
};

export function loadStoredData<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.warn(`Failed to parse localStorage item ${key}:`, err);
    return defaultValue;
  }
}

export function saveStoredData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error(`Failed to save to localStorage for key ${key}:`, err);
  }
}

export function getInitialOrStoredState() {
  return {
    incidents: loadStoredData<Incident[]>(STORAGE_KEYS.INCIDENTS, INITIAL_INCIDENTS),
    teams: loadStoredData<RescueTeam[]>(STORAGE_KEYS.TEAMS, INITIAL_RESCUE_TEAMS),
    shelters: loadStoredData<Shelter[]>(STORAGE_KEYS.SHELTERS, INITIAL_SHELTERS),
    hospitals: loadStoredData<Hospital[]>(STORAGE_KEYS.HOSPITALS, INITIAL_HOSPITALS),
    gauges: loadStoredData<RiverGaugeSensor[]>(STORAGE_KEYS.GAUGES, INITIAL_RIVER_GAUGES),
    notifications: loadStoredData<EmergencyNotification[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS),
    logs: loadStoredData<ActivityLog[]>(STORAGE_KEYS.LOGS, INITIAL_ACTIVITY_LOGS),
    currentUser: loadStoredData<UserProfile>(STORAGE_KEYS.CURRENT_USER, DEMO_USERS[0]),
  };
}

export function resetAllToDefaults() {
  localStorage.removeItem(STORAGE_KEYS.INCIDENTS);
  localStorage.removeItem(STORAGE_KEYS.TEAMS);
  localStorage.removeItem(STORAGE_KEYS.SHELTERS);
  localStorage.removeItem(STORAGE_KEYS.HOSPITALS);
  localStorage.removeItem(STORAGE_KEYS.GAUGES);
  localStorage.removeItem(STORAGE_KEYS.NOTIFICATIONS);
  localStorage.removeItem(STORAGE_KEYS.LOGS);
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
}

export function exportSystemStateAsJSON(state: any) {
  const jsonStr = JSON.stringify(state, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `aquashield_eoc_backup_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

import {
  AIRiskAssessment,
  AccessCondition,
  RiskFactorContribution,
  SeverityLevel,
  WaterLevelCondition,
} from '../types';

export interface RiskEngineInput {
  immediateDanger: boolean;
  affectedPeopleCount: number;
  hasMedicalUrgency: boolean;
  childrenCount: number;
  elderlyCount: number;
  specialNeedsCount: number;
  waterLevel: WaterLevelCondition;
  accessCondition: AccessCondition;
}

export const AI_MODEL_VERSION = 'AquaShield-RuleX-v2.6';

/**
 * Deterministic, transparent rule-based AI Risk Assessment Engine.
 * Provides verifiable point calculation and human-readable audit explanations.
 */
export function calculateAIRiskScore(input: RiskEngineInput): AIRiskAssessment {
  const factors: RiskFactorContribution[] = [];
  let totalScore = 0;

  // 1. Immediate Danger / Imminent Collapse / Fast Current (Max 25 pts)
  const immediateDangerScore = input.immediateDanger ? 25 : 0;
  totalScore += immediateDangerScore;
  factors.push({
    name: 'Immediate Hazard / Trapped Condition',
    score: immediateDangerScore,
    maxScore: 25,
    description: input.immediateDanger
      ? 'Active structural threat, fast-flowing water, or individuals directly stranded in perilous position.'
      : 'No immediate imminent physical collapse or direct high-velocity current reported.',
    triggered: input.immediateDanger,
  });

  // 2. Medical Urgency (Max 20 pts)
  const medicalScore = input.hasMedicalUrgency ? 20 : 0;
  totalScore += medicalScore;
  factors.push({
    name: 'Medical Urgency / Trauma',
    score: medicalScore,
    maxScore: 20,
    description: input.hasMedicalUrgency
      ? 'Life-critical trauma, oxygen dependency, hypothermia, or acute medical treatment required.'
      : 'No acute emergency medical crisis specified.',
    triggered: input.hasMedicalUrgency,
  });

  // 3. Vulnerable Populations: Children, Elderly, Special Needs (Max 20 pts)
  const totalVulnerable = (input.childrenCount || 0) + (input.elderlyCount || 0) + (input.specialNeedsCount || 0);
  let vulnerableScore = 0;
  if (totalVulnerable >= 5) {
    vulnerableScore = 20;
  } else if (totalVulnerable >= 2) {
    vulnerableScore = 15;
  } else if (totalVulnerable >= 1) {
    vulnerableScore = 10;
  }
  totalScore += vulnerableScore;
  factors.push({
    name: 'Vulnerable Population Multiplier',
    score: vulnerableScore,
    maxScore: 20,
    description: totalVulnerable > 0
      ? `Reported ${totalVulnerable} vulnerable person(s) (${input.childrenCount} children, ${input.elderlyCount} elderly, ${input.specialNeedsCount} special needs/infirm).`
      : 'Zero children, elderly, or special-needs individuals flagged.',
    triggered: totalVulnerable > 0,
  });

  // 4. Inundation Water Level Severity (Max 18 pts)
  let waterScore = 0;
  if (input.waterLevel === 'Fully Submerged / Rooftop') {
    waterScore = 18;
  } else if (input.waterLevel === 'Chest Depth (5ft+)') {
    waterScore = 15;
  } else if (input.waterLevel === 'Waist Depth (3-4ft)') {
    waterScore = 10;
  } else if (input.waterLevel === 'Knee Depth (1-2ft)') {
    waterScore = 6;
  } else {
    waterScore = 2;
  }
  totalScore += waterScore;
  factors.push({
    name: 'Inundation Water Level Depth',
    score: waterScore,
    maxScore: 18,
    description: `Water height assessed at "${input.waterLevel}". Risk escalates exponentially above waist height.`,
    triggered: waterScore >= 10,
  });

  // 5. Ingress & Access Barrier (Max 10 pts)
  let accessScore = 0;
  if (input.accessCondition === 'Air Evacuation Only') {
    accessScore = 10;
  } else if (input.accessCondition === 'Motorized Rescue Boat' || input.accessCondition === 'Inflatable Boat / Raft Only') {
    accessScore = 8;
  } else if (input.accessCondition === 'High-Clearance 4x4 Only') {
    accessScore = 4;
  } else {
    accessScore = 1;
  }
  totalScore += accessScore;
  factors.push({
    name: 'Geographic / Ingress Accessibility Barrier',
    score: accessScore,
    maxScore: 10,
    description: `Target zone requires specialized transport: "${input.accessCondition}". Severe obstacles delay response.`,
    triggered: accessScore >= 8,
  });

  // 6. Number of Affected People Scale (Max 7 pts)
  const count = input.affectedPeopleCount || 1;
  let headcountScore = 0;
  if (count >= 15) {
    headcountScore = 7;
  } else if (count >= 6) {
    headcountScore = 5;
  } else if (count >= 2) {
    headcountScore = 3;
  } else {
    headcountScore = 1;
  }
  totalScore += headcountScore;
  factors.push({
    name: 'Mass Scale / Affected Population',
    score: headcountScore,
    maxScore: 7,
    description: `Total of ${count} citizen(s) affected in immediate vicinity.`,
    triggered: headcountScore >= 5,
  });

  // Cap score between 0 and 100
  const finalScore = Math.min(100, Math.max(0, totalScore));

  // Determine Severity Level
  let severity: SeverityLevel = 'Safe';
  if (finalScore >= 75) {
    severity = 'Critical';
  } else if (finalScore >= 50) {
    severity = 'High';
  } else if (finalScore >= 25) {
    severity = 'Medium';
  } else {
    severity = 'Safe';
  }

  // Recommended Response & Dispatch Units
  let recommendedResponse = '';
  const recommendedUnits: string[] = [];

  if (severity === 'Critical') {
    recommendedResponse = 'IMMEDIATE AIR/WATER EXTRACTION & TRAUMA RESCUE';
    recommendedUnits.push('NDRF Flood Rescue Taskforce', 'Rapid Paramedic Unit');
    if (input.accessCondition === 'Air Evacuation Only') {
      recommendedUnits.push('Civil Aviation / IAF Helo SAR');
    } else {
      recommendedUnits.push('Zodiac Inflatable Fleet');
    }
  } else if (severity === 'High') {
    recommendedResponse = 'MOTORIZED BOAT EVACUATION & SHELTER TRANSFER';
    recommendedUnits.push('SDRF Water Wing', 'Emergency Medical Ambulance');
    if (totalVulnerable > 0) {
      recommendedUnits.push('Special Needs Transport');
    }
  } else if (severity === 'Medium') {
    recommendedResponse = 'HIGH-CLEARANCE VEHICLE DEPLOYMENT & RELIEF RATIONS';
    recommendedUnits.push('Civil Defense 4x4 Unit', 'Relief Supply Team');
  } else {
    recommendedResponse = 'PRECAUTIONARY MONITORING & LOCAL SHELTER ADVISORY';
    recommendedUnits.push('Local Community Patrol');
  }

  // Build Natural Language Explanation
  const reasonClauses: string[] = [];
  if (input.immediateDanger) {
    reasonClauses.push('immediate life-threatening structural danger or fast torrents');
  }
  if (input.hasMedicalUrgency) {
    reasonClauses.push('acute medical emergencies requiring immediate triage');
  }
  if (totalVulnerable > 0) {
    reasonClauses.push(`${totalVulnerable} vulnerable citizens (infants, elderly, or mobility-impaired) requiring specialized handling`);
  }
  if (input.waterLevel === 'Chest Depth (5ft+)' || input.waterLevel === 'Fully Submerged / Rooftop') {
    reasonClauses.push(`extreme water depths reaching ${input.waterLevel}`);
  }
  if (input.accessCondition === 'Motorized Rescue Boat' || input.accessCondition === 'Air Evacuation Only') {
    reasonClauses.push('impassable road access demanding waterborne or aerial craft');
  }

  let explanation = '';
  if (reasonClauses.length > 0) {
    explanation = `Priority score elevated to ${finalScore}/100 (${severity}) because: ${reasonClauses.join('; ')}. Immediate assignment recommended under standard Disaster Management Protocol.`;
  } else {
    explanation = `Standard priority score of ${finalScore}/100 calculated. Normal flood monitoring guidelines apply with low immediate trauma danger.`;
  }

  return {
    score: finalScore,
    severity,
    confidence: 96,
    recommendedResponse,
    recommendedUnits,
    factors,
    explanation,
    assessedAt: new Date().toISOString(),
    modelVersion: AI_MODEL_VERSION,
  };
}

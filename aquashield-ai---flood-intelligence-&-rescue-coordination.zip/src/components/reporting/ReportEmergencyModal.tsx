import React, { useState, useMemo } from 'react';
import {
  X,
  ShieldAlert,
  MapPin,
  Users,
  AlertTriangle,
  LifeBuoy,
  CheckCircle2,
  Sparkles,
  Info,
  Navigation,
  FileCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  EmergencyCategory,
  WaterLevelCondition,
  AccessCondition,
} from '../../types';
import { calculateAIRiskScore } from '../../services/aiRiskEngine';

const PRESET_LOCATIONS: {
  name: string;
  address: string;
  coords: [number, number];
}[] = [
  {
    name: 'Tilak Nagar Lowlands, Khan River, Indore',
    address: 'Near Old Waterworks Bridge, Tilak Nagar, Indore, MP 452018',
    coords: [22.7196, 75.8821],
  },
  {
    name: 'Ram Ghat Riverfront Steps, Ujjain',
    address: 'Near Harsiddhi Marg, Ram Ghat, Ujjain, MP 456006',
    coords: [23.1827, 75.7682],
  },
  {
    name: 'District Red Cross Hospital Vicinity, Dewas',
    address: 'Station Road, Dewas, MP 455001',
    coords: [22.9676, 76.0534],
  },
  {
    name: 'Bilawali Dam Spillway Outfall, Indore',
    address: 'Khandwa Road Bypass, Bilawali, Indore, MP 452020',
    coords: [22.6841, 75.8719],
  },
  {
    name: 'Bada Talab Southern Ghat, Bhopal',
    address: 'VIP Road Riverside Promenade, Bhopal, MP 462001',
    coords: [23.242, 77.385],
  },
];

export const ReportEmergencyModal: React.FC = () => {
  const { isReportModalOpen, setIsReportModalOpen, createIncident, setSelectedIncident } = useApp();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [reporterName, setReporterName] = useState('');
  const [reporterPhone, setReporterPhone] = useState('');
  const [reporterEmail, setReporterEmail] = useState('');

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<EmergencyCategory>('Flash Flood Rescue');
  const [description, setDescription] = useState('');
  const [locationName, setLocationName] = useState('');
  const [address, setAddress] = useState('');
  const [coordinates, setCoordinates] = useState<[number, number]>([22.7196, 75.8821]);

  const [affectedCount, setAffectedCount] = useState<number>(4);
  const [childrenCount, setChildrenCount] = useState<number>(1);
  const [elderlyCount, setElderlyCount] = useState<number>(1);
  const [specialNeedsCount, setSpecialNeedsCount] = useState<number>(0);
  const [hasMedicalUrgency, setHasMedicalUrgency] = useState<boolean>(false);
  const [waterLevel, setWaterLevel] = useState<WaterLevelCondition>('Waist Depth (3-4ft)');
  const [accessCondition, setAccessCondition] = useState<AccessCondition>('Motorized Rescue Boat');
  const [immediateDanger, setImmediateDanger] = useState<boolean>(true);

  const [neededResources, setNeededResources] = useState<string[]>([
    'Rescue Boat',
    'Evacuation',
    'Drinking Water',
  ]);
  const [consentAccepted, setConsentAccepted] = useState(true);
  const [submittedIncidentId, setSubmittedIncidentId] = useState<string | null>(null);
  const [submittedRefNumber, setSubmittedRefNumber] = useState<string | null>(null);

  // Live Risk Calculation Preview
  const liveRiskAssessment = useMemo(() => {
    return calculateAIRiskScore({
      immediateDanger,
      affectedPeopleCount: affectedCount,
      hasMedicalUrgency,
      childrenCount,
      elderlyCount,
      specialNeedsCount,
      waterLevel,
      accessCondition,
    });
  }, [
    immediateDanger,
    affectedCount,
    hasMedicalUrgency,
    childrenCount,
    elderlyCount,
    specialNeedsCount,
    waterLevel,
    accessCondition,
  ]);

  if (!isReportModalOpen) return null;

  const handlePresetSelect = (preset: (typeof PRESET_LOCATIONS)[0]) => {
    setLocationName(preset.name);
    setAddress(preset.address);
    setCoordinates(preset.coords);
  };

  const handleToggleResource = (res: string) => {
    if (neededResources.includes(res)) {
      setNeededResources(neededResources.filter((r) => r !== res));
    } else {
      setNeededResources([...neededResources, res]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !reporterName || !reporterPhone) {
      alert('Please fill in required reporter and incident details.');
      return;
    }

    const created = createIncident({
      title,
      category,
      description: description || 'Citizen reported rapid flood inundation requiring emergency response.',
      locationName: locationName || 'Indore Urban Basin Zone',
      address: address || 'Madhya Pradesh Flood Area',
      coordinates,
      reporterName,
      reporterPhone,
      reporterEmail,
      affectedPeopleCount: Number(affectedCount),
      childrenCount: Number(childrenCount),
      elderlyCount: Number(elderlyCount),
      specialNeedsCount: Number(specialNeedsCount),
      hasMedicalUrgency,
      waterLevel,
      accessCondition,
      immediateDanger,
      neededResources,
    });

    setSubmittedIncidentId(created.id);
    setSubmittedRefNumber(created.refNumber);
    setStep(4); // Success Confirmation Step
  };

  const handleClose = () => {
    setIsReportModalOpen(false);
    setStep(1);
    setSubmittedIncidentId(null);
    setSubmittedRefNumber(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Modal Top Header */}
        <div className="bg-[#101D2C] text-white px-6 py-4 flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-rose-500/20 text-[#D9535D] border border-rose-500/30">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">
                CITIZEN EMERGENCY REPORTING DISPATCH
              </h2>
              <p className="text-xs text-slate-400">
                AI-Assisted Emergency Dispatch Intake & Priority Triage
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        {step < 4 && (
          <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex items-center justify-between text-xs">
            <div className="flex items-center gap-6">
              <button
                onClick={() => setStep(1)}
                className={`font-semibold pb-0.5 border-b-2 flex items-center gap-1.5 ${
                  step === 1 ? 'border-[#36B9CA] text-[#172B3A]' : 'border-transparent text-slate-400'
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-[10px]">
                  1
                </span>
                Reporter Info
              </button>
              <button
                onClick={() => setStep(2)}
                className={`font-semibold pb-0.5 border-b-2 flex items-center gap-1.5 ${
                  step === 2 ? 'border-[#36B9CA] text-[#172B3A]' : 'border-transparent text-slate-400'
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-[10px]">
                  2
                </span>
                Incident & Location
              </button>
              <button
                onClick={() => setStep(3)}
                className={`font-semibold pb-0.5 border-b-2 flex items-center gap-1.5 ${
                  step === 3 ? 'border-[#36B9CA] text-[#172B3A]' : 'border-transparent text-slate-400'
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-[10px]">
                  3
                </span>
                Risk Assessment & AI Preview
              </button>
            </div>

            {/* Live AI Risk Pill in Header */}
            <div className="hidden sm:flex items-center gap-2 bg-white px-2.5 py-1 rounded-full border border-slate-200 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-[#36B9CA]" />
              <span className="text-[11px] font-semibold text-slate-600">Calculated Risk:</span>
              <span
                className={`font-mono font-bold text-xs ${
                  liveRiskAssessment.severity === 'Critical'
                    ? 'text-[#D9535D]'
                    : liveRiskAssessment.severity === 'High'
                    ? 'text-[#E88C43]'
                    : 'text-[#E7B64C]'
                }`}
              >
                {liveRiskAssessment.score}/100 ({liveRiskAssessment.severity})
              </span>
            </div>
          </div>
        )}

        {/* Modal Form Body */}
        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {step === 1 && (
            <div className="space-y-4">
              <div className="bg-blue-50/60 border border-blue-200 p-3.5 rounded-lg flex items-start gap-3 text-xs text-blue-900">
                <Info className="w-4 h-4 text-[#3478B9] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">Academic Demonstration Workflow:</span> Emergency dispatchers verify caller details to prevent false alarms and coordinate with field rescue units via callsigns.
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Reporter Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={reporterName}
                    onChange={(e) => setReporterName(e.target.value)}
                    placeholder="e.g. Ramesh Chandra Verma"
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Contact Phone Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={reporterPhone}
                    onChange={(e) => setReporterPhone(e.target.value)}
                    placeholder="e.g. +91 98260 12345"
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  value={reporterEmail}
                  onChange={(e) => setReporterEmail(e.target.value)}
                  placeholder="e.g. citizen@example.com"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                />
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    if (!reporterName || !reporterPhone) {
                      alert('Please enter your Name and Phone Number.');
                      return;
                    }
                    setStep(2);
                  }}
                  className="bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-5 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer"
                >
                  Proceed to Location & Details &rarr;
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Incident Headline / Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 5 People Trapped in Single-Story House along Khan River Bank"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Emergency Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as EmergencyCategory)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none bg-white"
                  >
                    <option value="Flash Flood Rescue">Flash Flood Rescue</option>
                    <option value="Structural Inundation">Structural Inundation</option>
                    <option value="Stranded Citizens">Stranded Citizens</option>
                    <option value="Medical Emergency in Flood">Medical Emergency in Flood</option>
                    <option value="Dam / Sluice Overflow Risk">Dam / Sluice Overflow Risk</option>
                    <option value="Bridge / Road Submergence">Bridge / Road Submergence</option>
                    <option value="Power Grid Hazard">Power Grid Hazard</option>
                    <option value="Animal Rescue">Animal Rescue</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Quick Landmark / Sector Presets
                  </label>
                  <select
                    onChange={(e) => {
                      const idx = Number(e.target.value);
                      if (!isNaN(idx) && PRESET_LOCATIONS[idx]) {
                        handlePresetSelect(PRESET_LOCATIONS[idx]);
                      }
                    }}
                    defaultValue=""
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none bg-slate-50"
                  >
                    <option value="" disabled>
                      Choose a High-Risk Demonstration Location...
                    </option>
                    {PRESET_LOCATIONS.map((p, idx) => (
                      <option key={p.name} value={idx}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Location Name / Colony
                  </label>
                  <input
                    type="text"
                    value={locationName}
                    onChange={(e) => setLocationName(e.target.value)}
                    placeholder="e.g. Tilak Nagar Riverside"
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    GPS Coordinates [Lat, Lng]
                  </label>
                  <input
                    type="text"
                    value={`${coordinates[0]}, ${coordinates[1]}`}
                    readOnly
                    className="w-full px-3 py-2 text-xs border border-slate-200 bg-slate-100 rounded-md font-mono text-slate-600 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Street Address & Landmark
                </label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Include landmarks, nearest bridge, temple, or water tank..."
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Detailed Situation Description
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe trapped status, building stability, rate of water rise, hazards..."
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                />
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="border border-slate-300 text-slate-700 hover:bg-slate-100 px-4 py-2 rounded-md text-xs font-semibold transition-colors"
                >
                  &larr; Back
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!title) {
                      alert('Please specify an incident title.');
                      return;
                    }
                    setStep(3);
                  }}
                  className="bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-5 py-2 rounded-md text-xs font-semibold transition-colors cursor-pointer"
                >
                  Proceed to Risk Assessment &rarr;
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5">
              {/* Emergency Vulnerability Assessment Matrix */}
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-4">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#3478B9]" /> Population & Special Assistance Counts
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] text-slate-500 mb-1 font-medium">Total Affected</label>
                    <input
                      type="number"
                      min={1}
                      max={200}
                      value={affectedCount}
                      onChange={(e) => setAffectedCount(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-bold text-[#172B3A] bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 mb-1 font-medium">Children (&lt;12 yrs)</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={childrenCount}
                      onChange={(e) => setChildrenCount(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-bold text-[#172B3A] bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 mb-1 font-medium">Elderly (60+ yrs)</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={elderlyCount}
                      onChange={(e) => setElderlyCount(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-bold text-[#172B3A] bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 mb-1 font-medium">Infirm / Special Needs</label>
                    <input
                      type="number"
                      min={0}
                      max={50}
                      value={specialNeedsCount}
                      onChange={(e) => setSpecialNeedsCount(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono font-bold text-[#172B3A] bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-200">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Water Level Depth Assessment
                    </label>
                    <select
                      value={waterLevel}
                      onChange={(e) => setWaterLevel(e.target.value as WaterLevelCondition)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-md bg-white text-slate-800"
                    >
                      <option value="Ankle Depth (< 1ft)">Ankle Depth (&lt; 1ft)</option>
                      <option value="Knee Depth (1-2ft)">Knee Depth (1-2ft)</option>
                      <option value="Waist Depth (3-4ft)">Waist Depth (3-4ft)</option>
                      <option value="Chest Depth (5ft+)">Chest Depth (5ft+)</option>
                      <option value="Fully Submerged / Rooftop">Fully Submerged / Rooftop Escape</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Access & Navigability Condition
                    </label>
                    <select
                      value={accessCondition}
                      onChange={(e) => setAccessCondition(e.target.value as AccessCondition)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-md bg-white text-slate-800"
                    >
                      <option value="Normal Vehicle">Normal Vehicle Passable</option>
                      <option value="High-Clearance 4x4 Only">High-Clearance 4x4 Only</option>
                      <option value="Inflatable Boat / Raft Only">Inflatable Boat / Raft Only</option>
                      <option value="Motorized Rescue Boat">Motorized Rescue Boat (Fast Current)</option>
                      <option value="Air Evacuation Only">Air Evacuation Only (Helicopter Winch)</option>
                    </select>
                  </div>
                </div>

                {/* Checkboxes: Danger & Medical */}
                <div className="flex flex-wrap gap-4 pt-2">
                  <label className="flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={immediateDanger}
                      onChange={(e) => setImmediateDanger(e.target.checked)}
                      className="rounded text-rose-600 focus:ring-rose-500 w-4 h-4"
                    />
                    <span className="text-rose-700">Immediate Life Threat / Fast Torrent / Structure Shaking</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={hasMedicalUrgency}
                      onChange={(e) => setHasMedicalUrgency(e.target.checked)}
                      className="rounded text-[#3478B9] focus:ring-blue-500 w-4 h-4"
                    />
                    <span>Acute Medical Urgency (Trauma, Oxygen, Hypothermia)</span>
                  </label>
                </div>
              </div>

              {/* Needed Resources Tag Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Requested Emergency Resources:
                </label>
                <div className="flex flex-wrap gap-2 text-xs">
                  {[
                    'Rescue Boat',
                    'Evacuation',
                    'Food Rations',
                    'Drinking Water',
                    'Medicines',
                    'Paramedic',
                    'Dewatering Pump',
                    'Blankets / Dry Clothing',
                  ].map((res) => {
                    const isSelected = neededResources.includes(res);
                    return (
                      <button
                        key={res}
                        type="button"
                        onClick={() => handleToggleResource(res)}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#101D2C] text-[#36B9CA] border-[#101D2C]'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {isSelected ? '✓ ' : '+ '}
                        {res}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Transparent AI Risk Breakdown Preview Card */}
              <div className="bg-[#101D2C] text-slate-200 p-4 rounded-lg border border-slate-700 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#36B9CA]">
                    <Sparkles className="w-4 h-4" />
                    TRANSPARENT AI RISK ASSESSMENT ENGINE PREVIEW
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    Engine: {liveRiskAssessment.modelVersion}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-slate-400">
                      Calculated Priority Score
                    </div>
                    <div className="text-3xl font-extrabold font-mono text-white">
                      {liveRiskAssessment.score}
                      <span className="text-sm font-normal text-slate-400"> / 100</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400">
                      Priority Classification
                    </div>
                    <div
                      className={`text-lg font-bold ${
                        liveRiskAssessment.severity === 'Critical'
                          ? 'text-[#D9535D]'
                          : liveRiskAssessment.severity === 'High'
                          ? 'text-[#E88C43]'
                          : 'text-[#E7B64C]'
                      }`}
                    >
                      {liveRiskAssessment.severity.toUpperCase()}
                    </div>
                  </div>
                </div>

                <div className="text-xs text-slate-300 bg-[#1B2C3D] p-2.5 rounded border border-slate-700">
                  <span className="text-[#36B9CA] font-semibold">Factor Audit: </span>
                  {liveRiskAssessment.explanation}
                </div>

                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>
                    Recommended Action: <strong className="text-white">{liveRiskAssessment.recommendedResponse}</strong>
                  </span>
                </div>
              </div>

              {/* Privacy Consent */}
              <label className="flex items-start gap-2 text-xs text-slate-600 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={consentAccepted}
                  onChange={(e) => setConsentAccepted(e.target.checked)}
                  className="rounded text-[#36B9CA] mt-0.5"
                />
                <span>
                  I confirm this emergency report represents a simulated flood incident for academic demonstration and will be transmitted to the AQUASHIELD EOC simulation registry.
                </span>
              </label>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="border border-slate-300 text-slate-700 hover:bg-slate-100 px-4 py-2 rounded-md text-xs font-semibold transition-colors"
                >
                  &larr; Back
                </button>
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={!consentAccepted}
                  className="bg-[#D9535D] hover:bg-[#c4434d] disabled:opacity-50 text-white px-6 py-2 rounded-md text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-2"
                >
                  <ShieldAlert className="w-4 h-4" />
                  CONFIRM & DISPATCH INCIDENT
                </button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-[#172B3A]">
                  EMERGENCY INCIDENT REGISTERED SUCCESSFULLY
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Transmitted to District Emergency Operations Center (DEOC) queue.
                </p>
              </div>

              <div className="bg-slate-50 max-w-md mx-auto p-4 rounded-lg border border-slate-200 text-xs text-left space-y-2">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="text-slate-500">Incident Reference ID:</span>
                  <span className="font-mono font-bold text-sm text-[#172B3A] bg-white px-2 py-0.5 rounded border border-slate-300">
                    {submittedRefNumber}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">AI Priority Level:</span>
                  <span className="font-bold text-[#D9535D]">{liveRiskAssessment.severity} ({liveRiskAssessment.score}/100)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Dispatch Routing:</span>
                  <span className="font-semibold text-slate-800">{liveRiskAssessment.recommendedResponse}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Estimated Response Sentry:</span>
                  <span className="font-mono font-semibold text-emerald-700">&lt; 14 Minutes ETA</span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-3 pt-4">
                <button
                  onClick={handleClose}
                  className="bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-6 py-2 rounded-md text-xs font-semibold cursor-pointer transition-colors"
                >
                  Return to Dashboard
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polygon } from 'react-leaflet';
import L from 'leaflet';
import { useApp } from '../../context/AppContext';
import { Incident, RescueTeam, Shelter, RiverGaugeSensor } from '../../types';
import { SeverityBadge } from '../common/SeverityBadge';
import { Layers, Navigation, ExternalLink, ShieldAlert, LifeBuoy, HeartPulse, Activity } from 'lucide-react';

// Create custom SVG DivIcons for crisp, high-tech GIS presentation
const createIncidentIcon = (severity: Incident['severity'], isSelected: boolean) => {
  let bgColor = '#D9535D';
  let pulse = true;
  if (severity === 'High') bgColor = '#E88C43';
  if (severity === 'Medium') {
    bgColor = '#E7B64C';
    pulse = false;
  }
  if (severity === 'Safe') {
    bgColor = '#2E9D76';
    pulse = false;
  }

  const html = `
    <div class="relative flex items-center justify-center">
      ${
        pulse
          ? `<span class="animate-ping absolute inline-flex h-8 w-8 rounded-full opacity-60" style="background-color: ${bgColor}"></span>`
          : ''
      }
      <div class="relative flex items-center justify-center w-7 h-7 rounded-full shadow-lg border-2 border-white transition-transform ${
        isSelected ? 'scale-125 ring-4 ring-cyan-400' : ''
      }" style="background-color: ${bgColor};">
        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
        </svg>
      </div>
    </div>
  `;

  return L.divIcon({
    html,
    className: 'custom-incident-pin',
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
};

const createTeamIcon = (status: RescueTeam['currentStatus']) => {
  const isMoving = status === 'Dispatched';
  const html = `
    <div class="relative flex items-center justify-center w-7 h-7 rounded-md bg-[#101D2C] border-2 border-[#36B9CA] shadow-md">
      ${
        isMoving
          ? `<span class="animate-ping absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-cyan-400"></span>`
          : ''
      }
      <svg class="w-4 h-4 text-[#36B9CA]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
      </svg>
    </div>
  `;
  return L.divIcon({
    html,
    className: 'custom-team-pin',
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
};

const createShelterIcon = () => {
  const html = `
    <div class="flex items-center justify-center w-7 h-7 rounded-md bg-[#2E9D76] border-2 border-white shadow-md">
      <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
      </svg>
    </div>
  `;
  return L.divIcon({
    html,
    className: 'custom-shelter-pin',
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
};

const createSensorIcon = (status: RiverGaugeSensor['status']) => {
  let color = '#3478B9';
  if (status === 'Critical Danger') color = '#D9535D';
  if (status === 'Warning') color = '#E88C43';

  const html = `
    <div class="flex items-center justify-center w-6 h-6 rounded-full border border-white shadow-md text-white font-mono text-[9px] font-bold" style="background-color: ${color}">
      <span>~</span>
    </div>
  `;
  return L.divIcon({
    html,
    className: 'custom-sensor-pin',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
};

interface EmergencyMapProps {
  height?: string;
  center?: [number, number];
  zoom?: number;
  highlightIncidentId?: string;
  onMapClick?: (lat: number, lng: number) => void;
  showControls?: boolean;
}

export const EmergencyMap: React.FC<EmergencyMapProps> = ({
  height = '500px',
  center = [22.7196, 75.8577], // Centered around Indore / Malwa
  zoom = 12,
  highlightIncidentId,
  showControls = true,
}) => {
  const {
    incidents,
    teams,
    shelters,
    gauges,
    setSelectedIncident,
    assignTeamToIncident,
    setCurrentView,
  } = useApp();

  const [layerVisibility, setLayerVisibility] = useState({
    incidents: true,
    teams: true,
    shelters: true,
    gauges: true,
    zones: true,
  });

  // Fictional Inundation Hazard Polygon (Khan River Basin corridor)
  const khanBasinInundationCoords: [number, number][] = [
    [22.735, 75.885],
    [22.728, 75.892],
    [22.715, 75.881],
    [22.705, 75.868],
    [22.712, 75.855],
    [22.725, 75.865],
  ];

  return (
    <div className="relative rounded-lg overflow-hidden border border-slate-200 shadow-xs bg-slate-100">
      {/* Map Layer Controls Bar */}
      {showControls && (
        <div className="absolute top-3 right-3 z-[1000] bg-white/95 backdrop-blur-xs p-2 rounded-lg border border-slate-200 shadow-md flex items-center gap-3 text-xs">
          <span className="font-semibold text-slate-700 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-[#36B9CA]" /> Layers:
          </span>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 hover:text-slate-900">
            <input
              type="checkbox"
              checked={layerVisibility.incidents}
              onChange={(e) => setLayerVisibility({ ...layerVisibility, incidents: e.target.checked })}
              className="rounded text-rose-500 focus:ring-rose-400"
            />
            <span>Incidents ({incidents.length})</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 hover:text-slate-900">
            <input
              type="checkbox"
              checked={layerVisibility.teams}
              onChange={(e) => setLayerVisibility({ ...layerVisibility, teams: e.target.checked })}
              className="rounded text-blue-500 focus:ring-blue-400"
            />
            <span>Rescue Units ({teams.length})</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 hover:text-slate-900">
            <input
              type="checkbox"
              checked={layerVisibility.shelters}
              onChange={(e) => setLayerVisibility({ ...layerVisibility, shelters: e.target.checked })}
              className="rounded text-emerald-500 focus:ring-emerald-400"
            />
            <span>Shelters ({shelters.length})</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 hover:text-slate-900">
            <input
              type="checkbox"
              checked={layerVisibility.gauges}
              onChange={(e) => setLayerVisibility({ ...layerVisibility, gauges: e.target.checked })}
              className="rounded text-cyan-600 focus:ring-cyan-500"
            />
            <span>River Gauges ({gauges.length})</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 hover:text-slate-900">
            <input
              type="checkbox"
              checked={layerVisibility.zones}
              onChange={(e) => setLayerVisibility({ ...layerVisibility, zones: e.target.checked })}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <span>Inundation Zone</span>
          </label>
        </div>
      )}

      {/* Main Leaflet Map */}
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height, width: '100%', zIndex: 1 }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* Hazard Inundation Overlay */}
        {layerVisibility.zones && (
          <>
            <Polygon
              positions={khanBasinInundationCoords}
              pathOptions={{
                color: '#D9535D',
                fillColor: '#D9535D',
                fillOpacity: 0.18,
                weight: 1.5,
                dashArray: '4, 4',
              }}
            >
              <Popup>
                <div className="p-1 text-xs">
                  <div className="font-bold text-rose-700">Active Flood Risk Zone</div>
                  <div className="text-slate-600 mt-0.5">Khan River Overbank Inundation Basin. High velocity current threat.</div>
                </div>
              </Popup>
            </Polygon>
            <Circle
              center={[23.1827, 75.7682]}
              radius={700}
              pathOptions={{
                color: '#E88C43',
                fillColor: '#E88C43',
                fillOpacity: 0.22,
                weight: 1.5,
              }}
            >
              <Popup>
                <div className="p-1 text-xs">
                  <div className="font-bold text-amber-700">Kshipra Ram Ghat Alert Zone</div>
                  <div className="text-slate-600">Water levels breaching temple plinths. Upstream reservoir discharge.</div>
                </div>
              </Popup>
            </Circle>
          </>
        )}

        {/* Incidents Markers */}
        {layerVisibility.incidents &&
          incidents.map((incident) => {
            const isSelected = highlightIncidentId === incident.id;
            return (
              <Marker
                key={incident.id}
                position={incident.coordinates}
                icon={createIncidentIcon(incident.severity, isSelected)}
              >
                <Popup>
                  <div className="w-64 p-1 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] text-slate-500 font-bold">{incident.refNumber}</span>
                      <SeverityBadge severity={incident.severity} size="sm" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm leading-snug">{incident.title}</h4>
                      <p className="text-slate-500 text-[11px] mt-0.5">{incident.locationName}</p>
                    </div>

                    <div className="bg-slate-50 p-2 rounded border border-slate-200 space-y-1 text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Affected People:</span>
                        <span className="font-bold text-slate-800 font-mono">{incident.affectedPeopleCount} citizens</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Water Condition:</span>
                        <span className="font-semibold text-rose-700">{incident.waterLevel}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">AI Risk Score:</span>
                        <span className="font-bold font-mono text-[#D9535D]">{incident.aiAssessment.score}/100</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => setSelectedIncident(incident)}
                        className="flex-1 bg-[#101D2C] hover:bg-[#1B2C3D] text-white py-1 px-2 rounded text-[11px] font-semibold text-center cursor-pointer transition-colors"
                      >
                        Incident Intel
                      </button>
                      <button
                        onClick={() => {
                          setSelectedIncident(incident);
                          setCurrentView('dispatch');
                        }}
                        className="bg-cyan-50 hover:bg-cyan-100 text-[#0e8fa3] border border-cyan-300 py-1 px-2 rounded text-[11px] font-semibold cursor-pointer transition-colors"
                      >
                        Dispatch
                      </button>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}

        {/* Rescue Team Markers */}
        {layerVisibility.teams &&
          teams.map((team) => (
            <Marker
              key={team.id}
              position={team.coordinates}
              icon={createTeamIcon(team.currentStatus)}
            >
              <Popup>
                <div className="w-56 p-1 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#172B3A]">{team.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 font-bold">
                      {team.agency}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500">Callsign: <span className="font-mono font-semibold">{team.callsign}</span></div>
                  <div className="text-[11px] text-slate-600">Status: <span className="font-semibold text-emerald-700">{team.currentStatus}</span></div>
                  <div className="text-[11px] text-slate-500 truncate">Loc: {team.currentLocationName}</div>
                  <div className="text-[10px] text-slate-400">Personnel: {team.personnelCount} rescuers | Battery: {team.fuelBatteryLevel}%</div>
                </div>
              </Popup>
            </Marker>
          ))}

        {/* Shelters Markers */}
        {layerVisibility.shelters &&
          shelters.map((shelter) => (
            <Marker key={shelter.id} position={shelter.coordinates} icon={createShelterIcon()}>
              <Popup>
                <div className="w-56 p-1 text-xs space-y-1.5">
                  <div className="font-bold text-slate-900">{shelter.name}</div>
                  <div className="text-slate-500 text-[11px]">{shelter.locationName}</div>
                  <div className="bg-emerald-50 p-1.5 rounded text-emerald-900 font-mono text-[11px] flex justify-between">
                    <span>Occupancy:</span>
                    <span>{shelter.currentOccupancy} / {shelter.totalCapacity} ({Math.round((shelter.currentOccupancy/shelter.totalCapacity)*100)}%)</span>
                  </div>
                  <div className="text-[10px] text-slate-500">Contact: {shelter.contactPerson} ({shelter.phone})</div>
                </div>
              </Popup>
            </Marker>
          ))}

        {/* River Gauge Sensors */}
        {layerVisibility.gauges &&
          gauges.map((gauge) => (
            <Marker key={gauge.id} position={gauge.coordinates} icon={createSensorIcon(gauge.status)}>
              <Popup>
                <div className="w-56 p-1 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">{gauge.riverOrBasin}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      gauge.status === 'Critical Danger' ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {gauge.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600">{gauge.stationName}</div>
                  <div className="font-mono bg-slate-50 p-1.5 rounded border border-slate-200 text-[11px] space-y-0.5">
                    <div>Water Level: <span className="font-bold text-rose-600">{gauge.currentWaterLevelMeters} m</span> (Danger: {gauge.dangerLevelMeters} m)</div>
                    <div>Flow Rate: {gauge.flowRateM3s} m³/s</div>
                    <div>Trend: <span className="text-[#3478B9] font-semibold">{gauge.trend}</span></div>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
      </MapContainer>
    </div>
  );
};

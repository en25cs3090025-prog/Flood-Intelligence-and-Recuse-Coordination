import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  Users,
  MapPin,
  Clock,
  Sparkles,
  CheckCircle2,
  Phone,
  ShieldCheck,
  Send,
  LifeBuoy,
  FileText,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SeverityBadge } from '../common/SeverityBadge';
import { IncidentStatus } from '../../types';

export const IncidentDetailModal: React.FC = () => {
  const {
    selectedIncident,
    setSelectedIncident,
    teams,
    updateIncidentStatus,
    assignTeamToIncident,
    currentUser,
  } = useApp();

  const [statusNote, setStatusNote] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState('');

  if (!selectedIncident) return null;

  const handleStatusChange = (newStatus: IncidentStatus) => {
    updateIncidentStatus(selectedIncident.id, newStatus, statusNote);
    setStatusNote('');
    // refresh selected incident view
    setSelectedIncident({
      ...selectedIncident,
      status: newStatus,
    });
  };

  const handleAssignTeam = () => {
    if (!selectedTeamId) return;
    assignTeamToIncident(selectedIncident.id, selectedTeamId, statusNote);
    const assignedTeam = teams.find((t) => t.id === selectedTeamId);
    setSelectedIncident({
      ...selectedIncident,
      assignedTeamId: selectedTeamId,
      assignedTeamName: assignedTeam?.name,
      status: 'Assigned',
    });
    setSelectedTeamId('');
  };

  const ai = selectedIncident.aiAssessment;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Modal Header */}
        <div className="bg-[#101D2C] text-white px-6 py-4 flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs bg-[#1B2C3D] text-[#36B9CA] px-2.5 py-1 rounded border border-[#36B9CA]/30 font-bold">
              {selectedIncident.refNumber}
            </span>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide truncate max-w-xl">
                {selectedIncident.title}
              </h2>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                <span>{selectedIncident.category}</span>
                <span>•</span>
                <span>{selectedIncident.locationName}</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => setSelectedIncident(null)}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {/* Top Status & Quick Metrics Bar */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-500 font-semibold uppercase">Current Status:</span>
              <span className="px-3 py-1 rounded-md bg-[#101D2C] text-[#36B9CA] text-xs font-mono font-bold">
                {selectedIncident.status.toUpperCase()}
              </span>
              <SeverityBadge severity={selectedIncident.severity} size="md" showPulse={true} />
            </div>

            <div className="flex items-center gap-4 text-xs font-mono text-slate-600">
              <div>
                <span className="text-slate-400">Reported: </span>
                <span className="font-semibold text-slate-800">
                  {new Date(selectedIncident.reportedAt).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Assigned Unit: </span>
                <span className="font-semibold text-blue-700">
                  {selectedIncident.assignedTeamName || 'Unassigned (Standby)'}
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Incident Details & Timeline */}
            <div className="lg:col-span-2 space-y-5">
              {/* Incident Synopsis */}
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Incident Synopsis & Location
                </h3>
                <p className="text-sm text-slate-800 leading-relaxed bg-white p-3.5 rounded-lg border border-slate-200">
                  {selectedIncident.description}
                </p>

                <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                    <span className="text-slate-400 block mb-0.5 font-medium">Exact Coordinates:</span>
                    <span className="font-mono font-semibold text-slate-800">
                      {selectedIncident.coordinates[0]}, {selectedIncident.coordinates[1]}
                    </span>
                  </div>
                  <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                    <span className="text-slate-400 block mb-0.5 font-medium">Street Address:</span>
                    <span className="font-semibold text-slate-800 truncate block">
                      {selectedIncident.address}
                    </span>
                  </div>
                </div>
              </div>

              {/* Vulnerability & Population Matrix */}
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Casualty & Vulnerability Telemetry
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                    <div className="text-[11px] text-slate-500 uppercase">Affected Citizens</div>
                    <div className="text-2xl font-bold font-mono text-slate-900 mt-1">
                      {selectedIncident.affectedPeopleCount}
                    </div>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                    <div className="text-[11px] text-slate-500 uppercase">Children (&lt;12)</div>
                    <div className="text-2xl font-bold font-mono text-amber-700 mt-1">
                      {selectedIncident.childrenCount}
                    </div>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                    <div className="text-[11px] text-slate-500 uppercase">Elderly (60+)</div>
                    <div className="text-2xl font-bold font-mono text-amber-700 mt-1">
                      {selectedIncident.elderlyCount}
                    </div>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                    <div className="text-[11px] text-slate-500 uppercase">Medical Urgency</div>
                    <div className={`text-sm font-bold mt-2 ${selectedIncident.hasMedicalUrgency ? 'text-rose-600' : 'text-slate-600'}`}>
                      {selectedIncident.hasMedicalUrgency ? 'YES (CRITICAL)' : 'NONE FLAGGED'}
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-2 text-xs">
                  <span className="px-2.5 py-1 rounded bg-slate-100 text-slate-700 font-medium border border-slate-200">
                    Water: <strong>{selectedIncident.waterLevel}</strong>
                  </span>
                  <span className="px-2.5 py-1 rounded bg-slate-100 text-slate-700 font-medium border border-slate-200">
                    Access: <strong>{selectedIncident.accessCondition}</strong>
                  </span>
                </div>
              </div>

              {/* Needed Resources */}
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Requested Field Resources
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedIncident.neededResources.map((res) => (
                    <span
                      key={res}
                      className="px-3 py-1 bg-cyan-50 text-[#0e8fa3] border border-cyan-200 rounded-full text-xs font-semibold"
                    >
                      {res}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Log Timeline */}
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Incident Operational Timeline
                </h3>
                <div className="border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100 max-h-48 overflow-y-auto">
                  {selectedIncident.timeline.map((item, idx) => (
                    <div key={idx} className="p-2.5 bg-white text-xs flex items-start gap-3">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-slate-800">{item.action}</span>
                          <span className="font-mono text-[10px] text-slate-400">
                            {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500">By {item.actor}</div>
                        {item.note && <div className="text-[11px] text-slate-600 italic mt-0.5">{item.note}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right 1 Col: Transparent AI Risk Engine Breakdown & Triage Controls */}
            <div className="space-y-5">
              {/* AI Risk Engine Box */}
              <div className="bg-[#101D2C] text-slate-200 p-4 rounded-xl border border-slate-700 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#36B9CA]">
                    <Sparkles className="w-4 h-4" />
                    AI RISK ASSESSMENT AUDIT
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    {ai.modelVersion}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[10px] uppercase text-slate-400">Priority Score</div>
                    <div className="text-3xl font-mono font-extrabold text-white">
                      {ai.score}
                      <span className="text-sm font-normal text-slate-400"> / 100</span>
                    </div>
                  </div>
                  <SeverityBadge severity={ai.severity} size="md" />
                </div>

                {/* Factor contribution progress bars */}
                <div className="space-y-2 pt-1 border-t border-slate-800 text-xs">
                  <div className="text-[10px] font-bold text-slate-400 uppercase">
                    Contributing Risk Factors:
                  </div>
                  {ai.factors.map((f, idx) => (
                    <div key={idx} className="space-y-0.5">
                      <div className="flex justify-between text-[11px]">
                        <span className={f.triggered ? 'text-white font-medium' : 'text-slate-400'}>
                          {f.name}
                        </span>
                        <span className="font-mono text-slate-300">
                          {f.score} / {f.maxScore}
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${
                            f.triggered
                              ? f.score > 15
                                ? 'bg-[#D9535D]'
                                : 'bg-[#36B9CA]'
                              : 'bg-slate-700'
                          }`}
                          style={{ width: `${(f.score / f.maxScore) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-[#1B2C3D] p-2.5 rounded text-[11px] text-slate-300 border border-slate-700">
                  <strong className="text-[#36B9CA]">AI Explanation: </strong>
                  {ai.explanation}
                </div>

                <div className="text-[11px] text-slate-300">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Recommended Deployment:</div>
                  <div className="font-semibold text-white mt-0.5">{ai.recommendedResponse}</div>
                </div>
              </div>

              {/* Operational Dispatch / Status Controls */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                  Triage & Dispatch Actions
                </h4>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Assign Rescue Unit:
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={selectedTeamId}
                      onChange={(e) => setSelectedTeamId(e.target.value)}
                      className="w-full text-xs px-2.5 py-1.5 border border-slate-200 rounded bg-white text-slate-800"
                    >
                      <option value="">Select Available Unit...</option>
                      {teams.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.currentStatus} - {t.agency})
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={handleAssignTeam}
                      disabled={!selectedTeamId}
                      className="bg-[#101D2C] hover:bg-[#1B2C3D] disabled:opacity-40 text-white text-xs px-3 py-1.5 rounded font-semibold cursor-pointer shrink-0"
                    >
                      Assign
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Transition Lifecycle Status:
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['Verified', 'Dispatched', 'On-Scene', 'Resolved', 'Closed'] as IncidentStatus[]).map((st) => (
                      <button
                        key={st}
                        onClick={() => handleStatusChange(st)}
                        className={`text-xs px-2.5 py-1.5 rounded font-semibold border transition-all cursor-pointer ${
                          selectedIncident.status === st
                            ? 'bg-[#101D2C] text-[#36B9CA] border-[#101D2C]'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Dispatcher Operational Note:
                  </label>
                  <input
                    type="text"
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    placeholder="e.g. Evacuation boat reached site..."
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-200 rounded bg-white text-slate-800"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

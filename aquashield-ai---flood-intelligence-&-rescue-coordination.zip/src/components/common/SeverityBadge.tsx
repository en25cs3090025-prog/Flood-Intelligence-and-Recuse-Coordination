import React from 'react';
import { SeverityLevel } from '../../types';

interface SeverityBadgeProps {
  severity: SeverityLevel;
  size?: 'sm' | 'md' | 'lg';
  showPulse?: boolean;
}

export const SeverityBadge: React.FC<SeverityBadgeProps> = ({
  severity,
  size = 'md',
  showPulse = false,
}) => {
  let colorClasses = '';
  let dotColor = '';

  switch (severity) {
    case 'Critical':
      colorClasses = 'bg-rose-50 text-[#D9535D] border-rose-200';
      dotColor = 'bg-[#D9535D]';
      break;
    case 'High':
      colorClasses = 'bg-amber-50 text-[#E88C43] border-amber-200';
      dotColor = 'bg-[#E88C43]';
      break;
    case 'Medium':
      colorClasses = 'bg-yellow-50 text-[#B48424] border-yellow-200';
      dotColor = 'bg-[#E7B64C]';
      break;
    case 'Safe':
    default:
      colorClasses = 'bg-emerald-50 text-[#2E9D76] border-emerald-200';
      dotColor = 'bg-[#2E9D76]';
      break;
  }

  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5 font-medium tracking-tight',
    md: 'text-xs px-2.5 py-1 font-semibold tracking-wide',
    lg: 'text-sm px-3.5 py-1.5 font-bold',
  }[size];

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border shadow-xs select-none ${colorClasses} ${sizeClasses}`}
    >
      <span className="relative flex h-2 w-2">
        {showPulse && severity === 'Critical' && (
          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${dotColor}`} />
        )}
        <span className={`relative inline-flex rounded-full h-2 w-2 ${dotColor}`} />
      </span>
      <span>{severity.toUpperCase()}</span>
    </span>
  );
};

import React, { useState, useEffect, useRef } from 'react';
import {
  Bell,
  Search,
  ShieldAlert,
  ChevronDown,
  UserCheck,
  LifeBuoy,
  LogOut,
  ExternalLink,
  Clock,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { DEMO_USERS } from '../../data/seedData';

export const Header: React.FC = () => {
  const {
    currentView,
    currentUser,
    switchUser,
    metrics,
    notifications,
    revokeNotification,
    setIsReportModalOpen,
    setIsAuthModalOpen,
    searchQuery,
    setSearchQuery,
    setCurrentView,
  } = useApp();

  const [timeStr, setTimeStr] = useState('');
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isRoleMenuOpen, setIsRoleMenuOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const roleRef = useRef<HTMLDivElement>(null);

  // Live Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('en-US', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' IST'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
      if (roleRef.current && !roleRef.current.contains(e.target as Node)) {
        setIsRoleMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getPageTitle = () => {
    switch (currentView) {
      case 'command-center':
        return 'Operations Command Center';
      case 'live-map':
        return 'Live GIS Flood Intelligence Map';
      case 'incidents':
        return 'Incident Operations & Triage';
      case 'rescue-teams':
        return 'Rescue Team Operations (NDRF / SDRF)';
      case 'dispatch':
        return 'Emergency Dispatch Control Room';
      case 'shelters':
        return 'Shelters & Relief Resources';
      case 'hospitals':
        return 'Hospitals & Medical Coordination';
      case 'notifications':
        return 'Emergency Broadcast Notifications';
      case 'analytics':
        return 'Intelligence & Hydrological Analytics';
      case 'simulator':
        return 'Disaster Scenario Simulator';
      case 'audit-logs':
        return 'System Audit & Activity Logs';
      case 'personnel':
        return 'Personnel & On-Duty Roster';
      case 'system-config':
        return 'System Configuration & AI Engine Parameters';
      case 'citizen-portal':
        return 'Citizen Emergency Reporting Portal';
      default:
        return 'AQUASHIELD AI';
    }
  };

  const activeAlerts = notifications.filter((n) => n.status === 'Active');

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      <div className="flex items-center justify-between px-6 py-2.5">
        {/* Left: Breadcrumb & Title */}
        <div className="flex items-center gap-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
              <span>EOC Central</span>
              <span>/</span>
              <span className="text-[#36B9CA] font-semibold">{currentUser.agency || 'Disaster Division'}</span>
            </div>
            <h1 className="text-lg font-bold text-[#172B3A] tracking-tight">{getPageTitle()}</h1>
          </div>
        </div>

        {/* Center: Search & Clock */}
        <div className="hidden lg:flex items-center gap-4 flex-1 max-w-md mx-8">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search incidents, locations, teams, sensor IDs..."
              className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-md text-xs text-[#172B3A] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] transition-all"
            />
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 text-slate-700 px-2.5 py-1.5 rounded text-xs font-mono border border-slate-200 shrink-0">
            <Clock className="w-3.5 h-3.5 text-[#3478B9]" />
            <span>{timeStr}</span>
          </div>
        </div>

        {/* Right Actions: SOS Button, Notifications, Role Switcher */}
        <div className="flex items-center gap-3">
          {/* Quick SOS Report Trigger */}
          <button
            onClick={() => setIsReportModalOpen(true)}
            className="flex items-center gap-2 bg-[#D9535D] hover:bg-[#c4434d] text-white px-3.5 py-1.5 rounded-md text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>REPORT EMERGENCY</span>
          </button>

          {/* Notifications Dropdown */}
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setIsNotifOpen(!isNotifOpen)}
              className="relative p-2 rounded-md hover:bg-slate-100 text-slate-600 transition-colors cursor-pointer"
              title="Operational Alerts"
            >
              <Bell className="w-4 h-4" />
              {activeAlerts.length > 0 && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#D9535D] rounded-full ring-2 ring-white"></span>
              )}
            </button>

            {isNotifOpen && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white border border-slate-200 rounded-lg shadow-xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-1">
                <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                    Active Alerts ({activeAlerts.length})
                  </span>
                  <button
                    onClick={() => {
                      setCurrentView('notifications');
                      setIsNotifOpen(false);
                    }}
                    className="text-xs text-[#3478B9] hover:underline font-semibold"
                  >
                    Manage All
                  </button>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                  {activeAlerts.length === 0 ? (
                    <div className="p-4 text-center text-xs text-slate-400">No active broadcast warnings.</div>
                  ) : (
                    activeAlerts.map((n) => (
                      <div key={n.id} className="p-3 hover:bg-slate-50 text-xs">
                        <div className="flex items-center justify-between">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              n.level.includes('Red')
                                ? 'bg-rose-100 text-[#D9535D]'
                                : n.level.includes('Amber')
                                ? 'bg-amber-100 text-[#E88C43]'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {n.level}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(n.issuedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <h4 className="font-semibold text-slate-800 mt-1">{n.title}</h4>
                        <p className="text-slate-500 mt-0.5 line-clamp-2">{n.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User & Role Switcher */}
          <div className="relative" ref={roleRef}>
            <button
              onClick={() => setIsRoleMenuOpen(!isRoleMenuOpen)}
              className="flex items-center gap-2.5 pl-2 pr-3 py-1 rounded-md border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all cursor-pointer"
            >
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-200"
              />
              <div className="text-left hidden sm:block">
                <div className="text-xs font-semibold text-[#172B3A] leading-tight truncate max-w-[130px]">
                  {currentUser.name}
                </div>
                <div className="text-[10px] font-medium text-[#36B9CA] uppercase tracking-wider">
                  {currentUser.role}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {isRoleMenuOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-lg shadow-xl z-50 overflow-hidden animate-in fade-in">
                <div className="p-3 bg-[#101D2C] text-white">
                  <div className="text-[11px] text-slate-400 uppercase font-semibold">Active Profile</div>
                  <div className="font-bold text-sm text-white mt-0.5">{currentUser.name}</div>
                  <div className="text-xs text-[#36B9CA]">{currentUser.agency || currentUser.role}</div>
                  {currentUser.callsign && (
                    <div className="text-[10px] font-mono text-slate-300 mt-1">Callsign: {currentUser.callsign}</div>
                  )}
                </div>

                <div className="p-2 border-b border-slate-100">
                  <div className="text-[10px] font-bold text-slate-400 uppercase px-2 py-1">
                    Switch Demo Role (Academic Evaluator)
                  </div>
                  {DEMO_USERS.map((user) => (
                    <button
                      key={user.id}
                      onClick={() => {
                        switchUser(user);
                        setIsRoleMenuOpen(false);
                      }}
                      className={`w-full text-left px-2 py-1.5 rounded text-xs flex items-center justify-between hover:bg-slate-100 transition-colors ${
                        currentUser.id === user.id ? 'bg-cyan-50 text-[#0e8fa3] font-semibold' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <UserCheck className="w-3.5 h-3.5" />
                        <div>
                          <div>{user.name}</div>
                          <div className="text-[10px] text-slate-400">{user.role}</div>
                        </div>
                      </div>
                      {currentUser.id === user.id && <span className="text-[10px] font-bold">ACTIVE</span>}
                    </button>
                  ))}
                </div>

                <div className="p-2 bg-slate-50">
                  <button
                    onClick={() => {
                      setIsAuthModalOpen(true);
                      setIsRoleMenuOpen(false);
                    }}
                    className="w-full text-left px-2 py-1.5 rounded text-xs text-slate-600 hover:bg-slate-200 flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Role Authentication Portal</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

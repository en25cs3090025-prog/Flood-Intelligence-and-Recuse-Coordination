import React, { useState } from 'react';
import { AlertTriangle, Info, X } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);

  if (collapsed) {
    return (
      <div className="bg-amber-50 border-b border-amber-200 px-4 py-1 text-xs text-amber-800 flex items-center justify-between">
        <span className="flex items-center gap-1.5 font-medium">
          <Info className="w-3.5 h-3.5 text-amber-600" />
          Academic Demonstration Prototype (B.Tech CSE Capstone Project) — All Telemetry & Incidents are Fictional.
        </span>
        <button
          onClick={() => setCollapsed(false)}
          className="text-amber-700 underline text-[11px] hover:text-amber-900 ml-2"
        >
          View Full Notice
        </button>
      </div>
    );
  }

  return (
    <div className="bg-[#101D2C] text-slate-300 border-b border-slate-700/60 px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-3 shadow-inner">
      <div className="flex items-center gap-2.5">
        <div className="bg-amber-500/20 text-amber-400 p-1 rounded">
          <AlertTriangle className="w-4 h-4" />
        </div>
        <div>
          <span className="font-semibold text-white tracking-wide mr-1.5">
            [ACADEMIC DEMONSTRATION PROTOTYPE]
          </span>
          <span className="text-slate-300">
            AQUASHIELD AI is a second-year B.Tech CSE emergency systems demonstration. Not affiliated with NDRF, SDRF, or official government disaster dispatch. All sensors, incidents, and responses are simulated test data.
          </span>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="inline-flex items-center gap-1 bg-[#1B2C3D] text-[#36B9CA] px-2 py-0.5 rounded text-[11px] font-mono border border-cyan-800/40">
          <span className="w-1.5 h-1.5 rounded-full bg-[#36B9CA] animate-pulse"></span>
          SIMULATION ENVIRONMENT ACTIVE
        </span>
        <button
          onClick={() => setCollapsed(true)}
          className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
          title="Minimize Notice"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

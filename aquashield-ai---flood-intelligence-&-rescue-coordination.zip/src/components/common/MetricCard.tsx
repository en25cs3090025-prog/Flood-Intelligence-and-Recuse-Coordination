import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtext?: string;
  trend?: string;
  trendPositive?: boolean;
  icon: LucideIcon;
  colorScheme?: 'navy' | 'cyan' | 'red' | 'amber' | 'emerald' | 'blue';
  onClick?: () => void;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtext,
  trend,
  trendPositive = true,
  icon: Icon,
  colorScheme = 'navy',
  onClick,
}) => {
  const schemeStyles = {
    navy: {
      iconBg: 'bg-slate-100 text-[#1B2C3D]',
      topBar: 'border-t-[#1B2C3D]',
    },
    cyan: {
      iconBg: 'bg-cyan-50 text-[#0e8fa3]',
      topBar: 'border-t-[#36B9CA]',
    },
    red: {
      iconBg: 'bg-rose-50 text-[#D9535D]',
      topBar: 'border-t-[#D9535D]',
    },
    amber: {
      iconBg: 'bg-amber-50 text-[#E88C43]',
      topBar: 'border-t-[#E88C43]',
    },
    emerald: {
      iconBg: 'bg-emerald-50 text-[#2E9D76]',
      topBar: 'border-t-[#2E9D76]',
    },
    blue: {
      iconBg: 'bg-blue-50 text-[#3478B9]',
      topBar: 'border-t-[#3478B9]',
    },
  }[colorScheme];

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-lg border border-slate-200/80 shadow-xs p-4 flex flex-col justify-between transition-all duration-150 border-t-2 ${
        schemeStyles.topBar
      } ${onClick ? 'cursor-pointer hover:shadow-md hover:border-slate-300' : ''}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold tracking-wider text-slate-500 uppercase">{title}</p>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold tracking-tight text-[#172B3A] font-mono">{value}</span>
            {trend && (
              <span
                className={`text-[11px] font-semibold px-1.5 py-0.5 rounded ${
                  trendPositive ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                }`}
              >
                {trend}
              </span>
            )}
          </div>
        </div>
        <div className={`p-2.5 rounded-md ${schemeStyles.iconBg}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      {subtext && (
        <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
          <span>{subtext}</span>
        </div>
      )}
    </div>
  );
};

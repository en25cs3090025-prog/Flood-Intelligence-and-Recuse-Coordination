import React, { useState } from 'react';
import {
  X,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ShieldCheck,
  UserCheck,
  Info,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { DEMO_USERS } from '../../data/seedData';
import { UserProfile } from '../../types';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, currentUser, switchUser } = useApp();

  const [email, setEmail] = useState(currentUser.email);
  const [password, setPassword] = useState('demo-eoc-2026');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [selectedPresetUser, setSelectedPresetUser] = useState<UserProfile>(currentUser);

  if (!isAuthModalOpen) return null;

  const handleSelectPreset = (user: UserProfile) => {
    setSelectedPresetUser(user);
    setEmail(user.email);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    switchUser(selectedPresetUser);
    setIsAuthModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="bg-[#101D2C] text-white p-6 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#36B9CA]/20 text-[#36B9CA] border border-[#36B9CA]/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">
                AQUASHIELD EOC ACCESS PORTAL
              </h2>
              <p className="text-xs text-slate-400">
                Disaster Response Role Authentication
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleLoginSubmit} className="p-6 space-y-4">
          <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg text-xs text-amber-900 flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Academic Prototype Notice:</span> Select a demo persona below to immediately simulate role-based authorization for faculty evaluation and technical viva.
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Select Demonstration Role:
            </label>
            <div className="space-y-2">
              {DEMO_USERS.map((user) => {
                const isSelected = selectedPresetUser.id === user.id;
                return (
                  <button
                    key={user.id}
                    type="button"
                    onClick={() => handleSelectPreset(user)}
                    className={`w-full text-left p-2.5 rounded-lg border text-xs flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#36B9CA] bg-cyan-50/70 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200"
                      />
                      <div>
                        <div className="font-bold text-[#172B3A]">{user.name}</div>
                        <div className="text-[11px] text-slate-500 font-medium">
                          {user.role} {user.callsign ? `• ${user.callsign}` : ''}
                        </div>
                      </div>
                    </div>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-[#36B9CA] text-white flex items-center justify-center">
                        <Check className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-10 py-2 text-xs border border-slate-200 rounded-md focus:ring-2 focus:ring-[#36B9CA]/30 focus:border-[#36B9CA] outline-none"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-600">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded text-[#36B9CA]"
                />
                <span>Remember session</span>
              </label>
              <span className="text-slate-400 text-[11px]">Academic Auth Simulator</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-[#101D2C] hover:bg-[#1B2C3D] text-white py-2.5 rounded-md text-xs font-bold transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <UserCheck className="w-4 h-4 text-[#36B9CA]" />
              AUTHENTICATE AS {selectedPresetUser.role.toUpperCase()}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

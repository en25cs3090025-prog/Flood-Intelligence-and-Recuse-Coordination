import React, { useState } from 'react';
import {
  LayoutDashboard,
  MapPin,
  AlertOctagon,
  Users2,
  Radio,
  Home,
  HeartPulse,
  BellRing,
  LineChart,
  FlaskConical,
  ScrollText,
  Contact,
  Sliders,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  Droplets,
  LifeBuoy,
} from 'lucide-react';
import { useApp, NavigationTab } from '../../context/AppContext';

export const Sidebar: React.FC = () => {
  const { currentView, setCurrentView, metrics, currentUser } = useApp();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const navItems: {
    id: NavigationTab;
    label: string;
    icon: React.ElementType;
    badge?: number | string;
    badgeColor?: string;
  }[] = [
    {
      id: 'command-center',
      label: 'Command Center',
      icon: LayoutDashboard,
    },
    {
      id: 'live-map',
      label: 'Live Flood Intelligence',
      icon: MapPin,
      badge: 'LIVE',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30',
    },
    {
      id: 'incidents',
      label: 'Incident Operations',
      icon: AlertOctagon,
      badge: metrics.activeEmergencies > 0 ? metrics.activeEmergencies : undefined,
      badgeColor: metrics.criticalIncidents > 0 ? 'bg-[#D9535D] text-white' : 'bg-amber-500 text-white',
    },
    {
      id: 'rescue-teams',
      label: 'Rescue Team Operations',
      icon: Users2,
      badge: `${metrics.deployedTeams} Act`,
      badgeColor: 'bg-blue-600/30 text-blue-300 border border-blue-500/30',
    },
    {
      id: 'dispatch',
      label: 'Dispatch Control Room',
      icon: Radio,
    },
    {
      id: 'shelters',
      label: 'Shelters & Relief Resources',
      icon: Home,
      badge: `${metrics.shelterOccupancyPercent}%`,
      badgeColor: 'bg-slate-700 text-slate-200',
    },
    {
      id: 'hospitals',
      label: 'Hospitals & Medical',
      icon: HeartPulse,
    },
    {
      id: 'notifications',
      label: 'Emergency Notifications',
      icon: BellRing,
      badge: metrics.unreadNotifications > 0 ? metrics.unreadNotifications : undefined,
      badgeColor: 'bg-[#D9535D] text-white',
    },
    {
      id: 'analytics',
      label: 'Intelligence & Analytics',
      icon: LineChart,
    },
    {
      id: 'simulator',
      label: 'Scenario Simulator',
      icon: FlaskConical,
      badge: 'TEST',
      badgeColor: 'bg-cyan-950 text-[#36B9CA] border border-cyan-700/40',
    },
    {
      id: 'audit-logs',
      label: 'Audit & Activity Logs',
      icon: ScrollText,
    },
    {
      id: 'personnel',
      label: 'Personnel Administration',
      icon: Contact,
    },
    {
      id: 'system-config',
      label: 'System Configuration',
      icon: Sliders,
    },
    {
      id: 'citizen-portal',
      label: 'Citizen SOS Portal',
      icon: LifeBuoy,
      badge: 'PUBLIC',
      badgeColor: 'bg-rose-950 text-rose-300 border border-rose-700/40',
    },
  ];

  return (
    <aside
      className={`bg-[#101D2C] text-slate-300 border-r border-slate-800 transition-all duration-200 flex flex-col justify-between shrink-0 select-none z-40 ${
        isCollapsed ? 'w-18' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div>
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/80 bg-[#0d1723]">
          {!isCollapsed && (
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="relative w-9 h-9 rounded-lg bg-linear-to-br from-[#36B9CA] to-[#1B2C3D] flex items-center justify-center p-0.5 shadow-md shrink-0">
                <div className="w-full h-full bg-[#101D2C] rounded-[6px] flex items-center justify-center">
                  <ShieldAlert className="w-5 h-5 text-[#36B9CA]" />
                </div>
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold tracking-wider text-white text-sm">AQUASHIELD</span>
                  <span className="text-[10px] font-bold bg-[#36B9CA]/20 text-[#36B9CA] px-1 py-0.2 rounded border border-[#36B9CA]/40">
                    AI
                  </span>
                </div>
                <span className="text-[9px] tracking-tight text-slate-400 font-medium uppercase truncate">
                  Disaster Intelligence EOC
                </span>
              </div>
            </div>
          )}

          {isCollapsed && (
            <div className="mx-auto w-9 h-9 rounded-lg bg-linear-to-br from-[#36B9CA] to-[#1B2C3D] flex items-center justify-center p-0.5">
              <ShieldAlert className="w-5 h-5 text-[#36B9CA]" />
            </div>
          )}

          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="p-2 space-y-0.5 max-h-[calc(100vh-160px)] overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs font-medium transition-all group relative cursor-pointer ${
                  isActive
                    ? 'bg-[#1B2C3D] text-[#36B9CA] font-semibold border-l-3 border-[#36B9CA] shadow-inner'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
                }`}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-[#36B9CA]' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                {!isCollapsed && <span className="truncate flex-1 text-left">{item.label}</span>}
                {!isCollapsed && item.badge !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold shrink-0 ${item.badgeColor || 'bg-slate-700 text-white'}`}>
                    {item.badge}
                  </span>
                )}

                {/* Floating tooltip when collapsed */}
                {isCollapsed && (
                  <div className="absolute left-full ml-2 px-2.5 py-1 bg-[#1B2C3D] text-white text-xs rounded shadow-lg whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50 border border-slate-700">
                    {item.label}
                  </div>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer System Status */}
      <div className="p-3 border-t border-slate-800/80 bg-[#0c1622]">
        {!isCollapsed ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                AI Sentinel Engine
              </span>
              <span className="text-emerald-400 font-mono text-[10px]">OPERATIONAL</span>
            </div>
            <div className="text-[10px] text-slate-500 font-mono flex items-center justify-between">
              <span>Telemetry Sensors</span>
              <span className="text-slate-400">5 / 5 ONLINE</span>
            </div>
          </div>
        ) : (
          <div className="flex justify-center" title="System Online">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
        )}
      </div>
    </aside>
  );
};

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DisclaimerBanner } from './components/common/DisclaimerBanner';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { AuthModal } from './components/common/AuthModal';
import { ReportEmergencyModal } from './components/reporting/ReportEmergencyModal';
import { IncidentDetailModal } from './components/incidents/IncidentDetailModal';

// Views
import { CommandCenterView } from './views/CommandCenterView';
import { LiveFloodIntelView } from './views/LiveFloodIntelView';
import { IncidentOperationsView } from './views/IncidentOperationsView';
import { RescueTeamOpsView } from './views/RescueTeamOpsView';
import { DispatchControlView } from './views/DispatchControlView';
import { SheltersReliefView } from './views/SheltersReliefView';
import { HospitalsMedicalView } from './views/HospitalsMedicalView';
import { NotificationsAlertsView } from './views/NotificationsAlertsView';
import { AnalyticsView } from './views/AnalyticsView';
import { ScenarioSimulatorView } from './views/ScenarioSimulatorView';
import { AuditLogsView } from './views/AuditLogsView';
import { PersonnelView } from './views/PersonnelView';
import { SystemConfigView } from './views/SystemConfigView';
import { CitizenPortalView } from './views/CitizenPortalView';

const MainContent: React.FC = () => {
  const { currentView } = useApp();

  const renderCurrentView = () => {
    switch (currentView) {
      case 'command-center':
        return <CommandCenterView />;
      case 'live-map':
        return <LiveFloodIntelView />;
      case 'incidents':
        return <IncidentOperationsView />;
      case 'rescue-teams':
        return <RescueTeamOpsView />;
      case 'dispatch':
        return <DispatchControlView />;
      case 'shelters':
        return <SheltersReliefView />;
      case 'hospitals':
        return <HospitalsMedicalView />;
      case 'notifications':
        return <NotificationsAlertsView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'simulator':
        return <ScenarioSimulatorView />;
      case 'audit-logs':
        return <AuditLogsView />;
      case 'personnel':
        return <PersonnelView />;
      case 'system-config':
        return <SystemConfigView />;
      case 'citizen-portal':
        return <CitizenPortalView />;
      default:
        return <CommandCenterView />;
    }
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 overflow-y-auto bg-[#F3F6F9]">
      <Header />
      <main className="flex-1 pb-12">{renderCurrentView()}</main>
      
      {/* Global Academic Capstone Footer */}
      <footer className="bg-white border-t border-slate-200 px-6 py-3 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <span className="font-extrabold text-[#101D2C] tracking-wide">AQUASHIELD AI</span>
          <span className="text-slate-300">|</span>
          <span>B.Tech Computer Science & Engineering Capstone Project</span>
        </div>
        <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400">
          <span>Simulation Engine: AquaShield-RuleX-v2.6</span>
          <span>GIS CRS: EPSG:3857 (WGS 84 / Pseudo-Mercator)</span>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <div className="flex flex-col h-screen w-screen overflow-hidden font-sans text-[#172B3A] antialiased">
        <DisclaimerBanner />
        <div className="flex flex-1 min-h-0 overflow-hidden">
          <Sidebar />
          <MainContent />
        </div>

        {/* Global Interactive Modals */}
        <ReportEmergencyModal />
        <IncidentDetailModal />
        <AuthModal />
      </div>
    </AppProvider>
  );
}

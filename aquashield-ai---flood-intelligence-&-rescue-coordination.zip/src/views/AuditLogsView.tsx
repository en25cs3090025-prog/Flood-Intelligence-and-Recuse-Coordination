import React, { useState, useMemo } from 'react';
import {
  ScrollText,
  Search,
  Filter,
  Download,
  Clock,
  ShieldCheck,
  User,
  Tag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ActivityLog } from '../types';

export const AuditLogsView: React.FC = () => {
  const { logs } = useApp();
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [logSearch, setLogSearch] = useState<string>('');

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const matchesCat = filterCategory === 'ALL' || log.category === filterCategory;
      const q = logSearch.toLowerCase();
      const matchesQ =
        log.action.toLowerCase().includes(q) ||
        log.details.toLowerCase().includes(q) ||
        log.user.toLowerCase().includes(q) ||
        (log.relatedRef && log.relatedRef.toLowerCase().includes(q));
      return matchesCat && matchesQ;
    });
  }, [logs, filterCategory, logSearch]);

  const exportAuditCSV = () => {
    const headers = ['Timestamp', 'Category', 'Action', 'Details', 'Actor', 'Role', 'Ref Number'];
    const rows = filteredLogs.map((l) => [
      l.timestamp,
      l.category,
      `"${l.action.replace(/"/g, '""')}"`,
      `"${l.details.replace(/"/g, '""')}"`,
      `"${l.user.replace(/"/g, '""')}"`,
      l.userRole,
      l.relatedRef || 'N/A',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `aquashield_audit_trail_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Operational Audit Trail & Activity Logs
          </h2>
          <p className="text-xs text-slate-500">
            Immutable chronological logging of all incident filings, AI recalculations, dispatch commands, and broadcasts.
          </p>
        </div>

        <button
          onClick={exportAuditCSV}
          className="flex items-center gap-2 border border-slate-300 hover:bg-slate-50 text-slate-700 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer"
        >
          <Download className="w-4 h-4 text-slate-500" />
          <span>Export Audit Log (CSV)</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-lg border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={logSearch}
              onChange={(e) => setLogSearch(e.target.value)}
              placeholder="Filter by action, user, or ref ID..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs outline-none focus:border-[#36B9CA]"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium">Category:</span>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-slate-700 outline-none"
            >
              <option value="ALL">All Categories</option>
              <option value="Incident">Incident</option>
              <option value="Dispatch">Dispatch</option>
              <option value="AI Risk Engine">AI Risk Engine</option>
              <option value="Notification">Notification</option>
              <option value="Shelter">Shelter</option>
              <option value="System">System</option>
            </select>
          </div>
        </div>

        <span className="font-mono text-[11px] text-slate-400">
          Showing {filteredLogs.length} events
        </span>
      </div>

      {/* Log Table */}
      <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#101D2C] text-slate-300 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Operational Details</th>
                <th className="py-3 px-4">Actor</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4 text-center">Reference ID</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredLogs.map((log) => {
                let badgeClass = 'bg-slate-100 text-slate-700';
                if (log.category === 'Incident') badgeClass = 'bg-rose-50 text-rose-700';
                if (log.category === 'Dispatch') badgeClass = 'bg-blue-50 text-blue-700';
                if (log.category === 'AI Risk Engine') badgeClass = 'bg-cyan-50 text-[#0e8fa3]';
                if (log.category === 'Notification') badgeClass = 'bg-amber-50 text-amber-700';
                if (log.category === 'Shelter') badgeClass = 'bg-emerald-50 text-emerald-700';

                return (
                  <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString([], {
                        month: 'short',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                      })}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${badgeClass}`}>
                        {log.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                      {log.action}
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-md truncate">
                      {log.details}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-800 whitespace-nowrap">
                      {log.user}
                    </td>
                    <td className="py-3 px-4 text-slate-500 text-[11px] whitespace-nowrap">
                      {log.userRole}
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-bold text-slate-700 whitespace-nowrap">
                      {log.relatedRef || '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

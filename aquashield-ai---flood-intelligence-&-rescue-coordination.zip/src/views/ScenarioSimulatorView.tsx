import React, { useState } from 'react';
import {
  FlaskConical,
  Play,
  RotateCcw,
  AlertTriangle,
  Zap,
  Sparkles,
  Waves,
  CheckCircle2,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SeverityBadge } from '../components/common/SeverityBadge';

export const ScenarioSimulatorView: React.FC = () => {
  const {
    scenarios,
    runScenarioSimulation,
    resetDemoData,
    isSimulating,
    setCurrentView,
  } = useApp();

  const [activeScenarioSuccess, setActiveScenarioSuccess] = useState<string | null>(null);

  const handleRun = (id: string, title: string) => {
    runScenarioSimulation(id);
    setActiveScenarioSuccess(`Drill scenario "${title}" executed. Water sensors surged and synthetic incidents injected.`);
    setTimeout(() => {
      setActiveScenarioSuccess(null);
    }, 4000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Disaster Scenario Simulator & EOC Stress Drill Engine
          </h2>
          <p className="text-xs text-slate-500">
            Inject synthetic extreme weather anomalies, river surges, and cascading emergency incidents for academic demonstration.
          </p>
        </div>

        <button
          onClick={resetDemoData}
          className="flex items-center gap-2 border border-slate-300 hover:bg-slate-50 text-slate-700 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer"
        >
          <RotateCcw className="w-4 h-4 text-slate-500" />
          <span>Reset All to Default Baseline</span>
        </button>
      </div>

      {activeScenarioSuccess && (
        <div className="bg-cyan-50 border border-cyan-200 p-4 rounded-xl flex items-center gap-3 text-[#0e8fa3] animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-[#36B9CA] shrink-0" />
          <div className="text-xs">
            <span className="font-bold">SIMULATION DRILL INJECTED: </span>
            {activeScenarioSuccess}
            <button
              onClick={() => setCurrentView('command-center')}
              className="ml-2 font-bold underline hover:text-cyan-900"
            >
              View on Command Center &rarr;
            </button>
          </div>
        </div>
      )}

      {/* Simulator Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {scenarios.map((sc) => {
          return (
            <div
              key={sc.id}
              className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:shadow-md transition-all space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-50 text-[#0e8fa3] border border-cyan-200">
                    DRILL SCENARIO
                  </span>
                  <SeverityBadge severity={sc.severity} size="sm" />
                </div>

                <div>
                  <h3 className="font-bold text-base text-[#172B3A]">{sc.title}</h3>
                  <div className="text-xs font-semibold text-[#E88C43] mt-0.5">{sc.subtitle}</div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                  {sc.description}
                </p>

                <div className="space-y-1.5 text-xs font-mono text-slate-600 pt-1">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Sensor Water Surge:</span>
                    <strong className="text-rose-600">+{sc.waterLevelSpikeMeters} Meters</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Injected Incidents:</span>
                    <strong className="text-slate-800">+{sc.simulatedIncidents.length} Emergency Cases</strong>
                  </div>
                  <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-100 truncate">
                    Zones: {sc.affectedRegions.join(', ')}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  onClick={() => handleRun(sc.id, sc.title)}
                  disabled={isSimulating}
                  className="w-full bg-[#101D2C] hover:bg-[#1B2C3D] disabled:opacity-50 text-white py-2.5 rounded-lg text-xs font-bold transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4 text-[#36B9CA]" />
                  <span>{isSimulating ? 'INJECTING SURGE...' : 'EXECUTE SCENARIO DRILL'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Methodology & Viva Explanation Card */}
      <div className="bg-[#101D2C] text-slate-300 p-5 rounded-xl border border-slate-700 space-y-3">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <FlaskConical className="w-4 h-4 text-[#36B9CA]" />
          <span>Academic Evaluation Note: Real-Time Event Injection Architecture</span>
        </div>
        <p className="text-xs leading-relaxed text-slate-300">
          When a scenario is triggered, the simulation engine calculates localized hydrological runoff coefficients, updates river telemetry gauge markers in state with sharp stage rises, feeds simulated high-urgency rescue incidents into the operational queue, and evaluates each with the Transparent AI Risk Engine. This demonstrates resilient system performance under high incident concurrency.
        </p>
      </div>
    </div>
  );
};

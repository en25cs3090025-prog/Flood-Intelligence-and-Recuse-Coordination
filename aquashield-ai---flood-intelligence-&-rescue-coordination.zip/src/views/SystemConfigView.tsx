import React, { useState } from 'react';
import {
  Sliders,
  Download,
  RotateCcw,
  Sparkles,
  Shield,
  Save,
  CheckCircle2,
  FileCode,
  Info,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AI_MODEL_VERSION } from '../services/aiRiskEngine';

export const SystemConfigView: React.FC = () => {
  const { exportJSON, resetDemoData, incidents } = useApp();

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [criticalThreshold, setCriticalThreshold] = useState(75);
  const [highThreshold, setHighThreshold] = useState(50);
  const [immediateDangerWeight, setImmediateDangerWeight] = useState(25);
  const [medicalUrgencyWeight, setMedicalUrgencyWeight] = useState(20);
  const [vulnerablePopulationWeight, setVulnerablePopulationWeight] = useState(20);
  const [waterDepthWeight, setWaterDepthWeight] = useState(18);

  const handleSaveWeights = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
    }, 3000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            System Configuration & AI Engine Parameters
          </h2>
          <p className="text-xs text-slate-500">
            Tune algorithmic risk priority weights, threshold triggers, and manage system database snapshots.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={exportJSON}
            className="flex items-center gap-2 bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-4 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#36B9CA]" />
            <span>Export Drill Snapshot (JSON)</span>
          </button>
          <button
            onClick={resetDemoData}
            className="flex items-center gap-2 border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-slate-500" />
            <span>Reset Demo Baseline</span>
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl flex items-center gap-2 text-emerald-800 text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>AI Parameter Weights updated successfully for current runtime session.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: AI Engine Parameter Tuning */}
        <form
          onSubmit={handleSaveWeights}
          className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-5"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#36B9CA]" />
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                Transparent AI Risk Scoring Weights Calibration
              </h3>
            </div>
            <span className="text-[10px] font-mono text-slate-400">{AI_MODEL_VERSION}</span>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between font-semibold text-slate-700 mb-1">
                <span>Immediate Hazard / Peril Weight</span>
                <span className="font-mono text-[#101D2C]">{immediateDangerWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={40}
                value={immediateDangerWeight}
                onChange={(e) => setImmediateDangerWeight(Number(e.target.value))}
                className="w-full accent-[#36B9CA] cursor-pointer"
              />
              <span className="text-[11px] text-slate-400">Structural damage, fast current torrents</span>
            </div>

            <div>
              <div className="flex justify-between font-semibold text-slate-700 mb-1">
                <span>Acute Medical Urgency Weight</span>
                <span className="font-mono text-[#101D2C]">{medicalUrgencyWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={30}
                value={medicalUrgencyWeight}
                onChange={(e) => setMedicalUrgencyWeight(Number(e.target.value))}
                className="w-full accent-[#36B9CA] cursor-pointer"
              />
              <span className="text-[11px] text-slate-400">Oxygen-dependent, hypothermia, acute trauma</span>
            </div>

            <div>
              <div className="flex justify-between font-semibold text-slate-700 mb-1">
                <span>Vulnerable Populations Multiplier (Children & Elderly)</span>
                <span className="font-mono text-[#101D2C]">{vulnerablePopulationWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={30}
                value={vulnerablePopulationWeight}
                onChange={(e) => setVulnerablePopulationWeight(Number(e.target.value))}
                className="w-full accent-[#36B9CA] cursor-pointer"
              />
              <span className="text-[11px] text-slate-400">Infants, non-ambulatory seniors, special needs</span>
            </div>

            <div>
              <div className="flex justify-between font-semibold text-slate-700 mb-1">
                <span>Inundation Depth Severity Weight</span>
                <span className="font-mono text-[#101D2C]">{waterDepthWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={25}
                value={waterDepthWeight}
                onChange={(e) => setWaterDepthWeight(Number(e.target.value))}
                className="w-full accent-[#36B9CA] cursor-pointer"
              />
              <span className="text-[11px] text-slate-400">Submerged rooftops, chest-deep waters</span>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              className="bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-5 py-2 rounded-md text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5 text-[#36B9CA]" />
              <span>Apply Configuration</span>
            </button>
          </div>
        </form>

        {/* Right Column: Platform Metadata & State Management */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4 text-xs">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <Shield className="w-4 h-4 text-[#3478B9]" />
              <h3 className="font-bold text-[#172B3A] uppercase tracking-wide">
                Database Snapshots & Evaluation Artifacts
              </h3>
            </div>

            <p className="text-slate-600 leading-relaxed">
              Export the entire operational state (active incidents, rescue deployments, shelter allocations, sensor logs, and audit entries) as a self-contained JSON artifact for grading, faculty defense, or cross-browser replication.
            </p>

            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 font-mono space-y-1 text-[11px]">
              <div>System Version: <strong>AQUASHIELD AI v2.6-ENTERPRISE-DEMO</strong></div>
              <div>Persistence: <strong>Browser localStorage (Synchronized)</strong></div>
              <div>Current Incident Count: <strong>{incidents.length} active records</strong></div>
              <div>Model: <strong>Rule-X Deterministic Explanatory Engine</strong></div>
            </div>

            <div className="pt-2 flex gap-3">
              <button
                onClick={exportJSON}
                className="flex-1 bg-[#101D2C] hover:bg-[#1B2C3D] text-white py-2 rounded-md font-semibold text-center cursor-pointer transition-colors"
              >
                Download State JSON
              </button>
              <button
                onClick={resetDemoData}
                className="flex-1 border border-rose-300 text-rose-700 hover:bg-rose-50 py-2 rounded-md font-semibold text-center cursor-pointer transition-colors"
              >
                Flush State
              </button>
            </div>
          </div>

          <div className="bg-[#101D2C] text-slate-300 p-5 rounded-xl border border-slate-700 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-white font-bold">
              <Info className="w-4 h-4 text-[#36B9CA]" />
              <span>Academic Integrity Notice</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              This software was designed for computer science engineering evaluation. No external paid APIs or proprietary closed services are required for full offline operation. All operational calculations are self-contained and auditable.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

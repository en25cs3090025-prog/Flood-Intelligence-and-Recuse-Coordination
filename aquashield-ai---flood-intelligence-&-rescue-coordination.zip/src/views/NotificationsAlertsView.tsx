import React, { useState } from 'react';
import {
  BellRing,
  Radio,
  Volume2,
  Send,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Flame,
  XCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EmergencyNotification } from '../types';

export const NotificationsAlertsView: React.FC = () => {
  const { notifications, createEmergencyNotification, revokeNotification, currentUser } = useApp();

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [level, setLevel] = useState<EmergencyNotification['level']>('Amber Alert (Warning)');
  const [zonesInput, setZonesInput] = useState('Khan River Corridor, Tilak Nagar, Juni Indore');
  const [selectedChannels, setSelectedChannels] = useState<EmergencyNotification['channels']>([
    'EOC Broadcast',
    'SMS Blast',
    'Mobile App Notification',
  ]);
  const [sirenActive, setSirenActive] = useState(false);

  const handleToggleChannel = (ch: any) => {
    if (selectedChannels.includes(ch)) {
      setSelectedChannels(selectedChannels.filter((c) => c !== ch));
    } else {
      setSelectedChannels([...selectedChannels, ch]);
    }
  };

  const handleCreateBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !message) {
      alert('Please fill in alert title and emergency advisory message.');
      return;
    }

    createEmergencyNotification({
      title,
      message,
      level,
      affectedZones: zonesInput.split(',').map((z) => z.trim()),
      issuedBy: `${currentUser.name} (${currentUser.agency || currentUser.role})`,
      channels: selectedChannels,
    });

    setTitle('');
    setMessage('');
  };

  const handleTriggerSiren = () => {
    setSirenActive(true);
    setTimeout(() => {
      setSirenActive(false);
    }, 4000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Emergency Public Broadcast & Warning Network
          </h2>
          <p className="text-xs text-slate-500">
            Common Alerting Protocol (CAP) compliant multi-channel flood warning transmission.
          </p>
        </div>

        <button
          onClick={handleTriggerSiren}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs font-bold transition-all shadow-md cursor-pointer ${
            sirenActive
              ? 'bg-[#D9535D] text-white animate-bounce'
              : 'bg-[#101D2C] hover:bg-[#1B2C3D] text-amber-400 border border-amber-400/40'
          }`}
        >
          <Volume2 className="w-4 h-4" />
          <span>{sirenActive ? 'SIREN TRIGGER ACTIVE (TEST)' : 'TEST MUNICIPAL SIRENS'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Create New Emergency Broadcast (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <form
            onSubmit={handleCreateBroadcast}
            className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-5 space-y-4 text-xs"
          >
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <div className="p-1.5 rounded bg-rose-50 text-[#D9535D]">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 uppercase">
                  Broadcast New Emergency Alert
                </h3>
                <span className="text-[10px] text-slate-400">
                  Transmits across radio towers & cellular towers
                </span>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Alert Severity Classification
              </label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white text-slate-800"
              >
                <option value="Red Alert (Critical)">Red Alert (Critical Threat / Evacuate)</option>
                <option value="Amber Alert (Warning)">Amber Alert (Severe Warning / Be Prepared)</option>
                <option value="Yellow Alert (Watch)">Yellow Alert (Weather Watch / Monitor)</option>
                <option value="Informational">Informational Public Bulletin</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Alert Headline</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. FLASH SURGE WARNING: Kshipra River Overflow"
                className="w-full px-3 py-2 border border-slate-200 rounded-md outline-none focus:border-[#36B9CA]"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Public Safety Advisory Message
              </label>
              <textarea
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Clear instructions for citizens regarding evacuation routes and shelter locations..."
                className="w-full px-3 py-2 border border-slate-200 rounded-md outline-none focus:border-[#36B9CA]"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Target Sectors / Affected Zones (comma-separated)
              </label>
              <input
                type="text"
                value={zonesInput}
                onChange={(e) => setZonesInput(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-md outline-none focus:border-[#36B9CA]"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-2">
                Active Transmission Channels:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Public Siren', 'SMS Blast', 'EOC Broadcast', 'Mobile App Notification'] as const).map(
                  (ch) => {
                    const isChecked = selectedChannels.includes(ch);
                    return (
                      <button
                        key={ch}
                        type="button"
                        onClick={() => handleToggleChannel(ch)}
                        className={`p-2 rounded text-left border transition-all cursor-pointer ${
                          isChecked
                            ? 'bg-[#101D2C] text-[#36B9CA] border-[#101D2C] font-semibold'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {isChecked ? '✓ ' : '+ '}
                        {ch}
                      </button>
                    );
                  }
                )}
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full bg-[#D9535D] hover:bg-[#c4434d] text-white py-2.5 rounded-md font-bold transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <Radio className="w-4 h-4" />
                TRANSMIT EMERGENCY BROADCAST
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Active & Historical Broadcast Registry (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide flex items-center gap-2">
                <BellRing className="w-4 h-4 text-[#3478B9]" /> Broadcast Transmission Archive
              </h3>
              <span className="text-xs font-mono font-bold text-slate-500">
                {notifications.filter((n) => n.status === 'Active').length} Active
              </span>
            </div>

            <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
              {notifications.map((n) => {
                const isActive = n.status === 'Active';
                const isRed = n.level.includes('Red');
                const isAmber = n.level.includes('Amber');

                return (
                  <div
                    key={n.id}
                    className={`p-4 rounded-xl border transition-all space-y-2 ${
                      isActive
                        ? isRed
                          ? 'border-rose-300 bg-rose-50/30'
                          : isAmber
                          ? 'border-amber-300 bg-amber-50/30'
                          : 'border-yellow-300 bg-yellow-50/20'
                        : 'border-slate-200 bg-slate-50 opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                          isRed
                            ? 'bg-rose-100 text-[#D9535D]'
                            : isAmber
                            ? 'bg-amber-100 text-[#E88C43]'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {n.level}
                      </span>
                      <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
                        <span>
                          {new Date(n.issuedAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        {isActive ? (
                          <button
                            onClick={() => revokeNotification(n.id)}
                            className="text-slate-500 hover:text-rose-600 font-semibold cursor-pointer"
                          >
                            Revoke
                          </button>
                        ) : (
                          <span className="text-slate-400 italic">Revoked</span>
                        )}
                      </div>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 leading-snug">{n.title}</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>

                    <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-200/60">
                      <div>
                        Zones: <strong className="text-slate-700">{n.affectedZones.join(', ')}</strong>
                      </div>
                      <div className="flex items-center gap-1">
                        Channels: <span className="font-mono text-slate-600">{n.channels.join(', ')}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

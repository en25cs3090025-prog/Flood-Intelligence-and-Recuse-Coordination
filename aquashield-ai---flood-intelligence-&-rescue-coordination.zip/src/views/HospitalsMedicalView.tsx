import React from 'react';
import {
  HeartPulse,
  Activity,
  Ambulance,
  Phone,
  Bed,
  CheckCircle2,
  AlertTriangle,
  Stethoscope,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const HospitalsMedicalView: React.FC = () => {
  const { hospitals } = useApp();

  const totalBeds = hospitals.reduce((acc, h) => acc + h.totalBeds, 0);
  const availBeds = hospitals.reduce((acc, h) => acc + h.availableBeds, 0);
  const availIcu = hospitals.reduce((acc, h) => acc + h.traumaIcuAvailable, 0);
  const availAmbulances = hospitals.reduce((acc, h) => acc + h.availableAmbulances, 0);

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Hospitals & Trauma Medical Coordination
          </h2>
          <p className="text-xs text-slate-500">
            Designated emergency reception hospitals, ICU trauma surge capacity, oxygen supply, and ambulance fleets.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono bg-white px-3.5 py-1.5 rounded-lg border border-slate-200">
          <div>
            <span className="text-slate-400">Total Available Beds: </span>
            <strong className="text-slate-800">{availBeds} / {totalBeds}</strong>
          </div>
          <span className="text-slate-300">|</span>
          <div>
            <span className="text-slate-400">ICU / Trauma: </span>
            <strong className="text-rose-600 font-bold">{availIcu} Free</strong>
          </div>
          <span className="text-slate-300">|</span>
          <div>
            <span className="text-slate-400">Ambulances: </span>
            <strong className="text-emerald-700">{availAmbulances} Ready</strong>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {hospitals.map((hosp) => (
          <div
            key={hosp.id}
            className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:shadow-md transition-all space-y-4"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-50 text-rose-800 border border-rose-200">
                    TRAUMA CENTER
                  </span>
                  <h3 className="font-bold text-base text-[#172B3A] mt-1">{hosp.name}</h3>
                  <p className="text-xs text-slate-500">{hosp.address}</p>
                </div>

                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  ED OPEN 24/7
                </span>
              </div>

              {/* Bed & ICU Capacity Stats */}
              <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block uppercase">General Beds</span>
                  <span className="font-mono font-bold text-base text-slate-800 mt-0.5 block">
                    {hosp.availableBeds} / {hosp.totalBeds}
                  </span>
                </div>

                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block uppercase">Trauma ICU</span>
                  <span className="font-mono font-bold text-base text-rose-700 mt-0.5 block">
                    {hosp.traumaIcuAvailable} Free
                  </span>
                </div>

                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <span className="text-[10px] text-slate-400 block uppercase">Ambulances</span>
                  <span className="font-mono font-bold text-base text-blue-700 mt-0.5 block">
                    {hosp.availableAmbulances} / {hosp.ambulanceCount}
                  </span>
                </div>
              </div>

              {/* Oxygen & Utilities */}
              <div className="mt-4 flex items-center justify-between text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-600" />
                  <span className="text-slate-600">Oxygen Reserves:</span>
                </div>
                <span
                  className={`font-semibold font-mono px-2 py-0.5 rounded text-[11px] ${
                    hosp.oxygenStatus === 'Adequate'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {hosp.oxygenStatus}
                </span>
              </div>
            </div>

            {/* Footer with Contact Helpline */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                Emergency ED Desk: <strong className="text-slate-800">{hosp.contactPhone}</strong>
              </span>
              <span className="font-mono text-emerald-700 text-[11px] font-semibold">DIRECT RADIO LINKED</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

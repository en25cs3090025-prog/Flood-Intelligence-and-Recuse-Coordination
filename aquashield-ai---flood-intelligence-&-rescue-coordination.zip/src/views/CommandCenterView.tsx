import React from 'react';
import {
  AlertOctagon,
  Flame,
  ShieldAlert,
  Users,
  Radio,
  Home,
  HeartPulse,
  Clock,
  ArrowRight,
  TrendingUp,
  Activity,
  Sparkles,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MetricCard } from '../components/common/MetricCard';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { EmergencyMap } from '../components/map/EmergencyMap';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';

export const CommandCenterView: React.FC = () => {
  const {
    metrics,
    incidents,
    teams,
    shelters,
    gauges,
    setSelectedIncident,
    setCurrentView,
    setIsReportModalOpen,
    logs,
  } = useApp();

  // Sort active incidents by AI risk score descending
  const prioritizedIncidents = [...incidents]
    .filter((i) => i.status !== 'Resolved' && i.status !== 'Closed')
    .sort((a, b) => b.aiAssessment.score - a.aiAssessment.score);

  // Recharts severity distribution data
  const severityData = [
    { name: 'Critical', value: incidents.filter((i) => i.severity === 'Critical').length, color: '#D9535D' },
    { name: 'High', value: incidents.filter((i) => i.severity === 'High').length, color: '#E88C43' },
    { name: 'Medium', value: incidents.filter((i) => i.severity === 'Medium').length, color: '#E7B64C' },
    { name: 'Safe', value: incidents.filter((i) => i.severity === 'Safe').length, color: '#2E9D76' },
  ].filter((d) => d.value > 0);

  // River water telemetry trend (simulated 24hr timeline)
  const waterTrendData = [
    { time: '00:00', khanRiver: 3.1, kshipraRiver: 4.8 },
    { time: '02:00', khanRiver: 3.3, kshipraRiver: 5.0 },
    { time: '04:00', khanRiver: 3.9, kshipraRiver: 5.4 },
    { time: '05:00', khanRiver: 4.4, kshipraRiver: 5.9 },
    { time: '06:00', khanRiver: 4.85, kshipraRiver: 6.2 },
    { time: 'Now', khanRiver: 4.95, kshipraRiver: 6.3 },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Top 9 KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3.5">
        <MetricCard
          title="Total Incidents"
          value={metrics.totalIncidents}
          subtext="Logged in current operational cycle"
          icon={AlertOctagon}
          colorScheme="navy"
          onClick={() => setCurrentView('incidents')}
        />
        <MetricCard
          title="Active Emergencies"
          value={metrics.activeEmergencies}
          trend="+2 recent"
          trendPositive={false}
          subtext="Under ongoing response"
          icon={Flame}
          colorScheme="red"
          onClick={() => setCurrentView('incidents')}
        />
        <MetricCard
          title="Critical Risk Cases"
          value={metrics.criticalIncidents}
          subtext="AI Score &ge; 75 / 100"
          icon={ShieldAlert}
          colorScheme="red"
        />
        <MetricCard
          title="High Priority"
          value={metrics.highIncidents}
          subtext="AI Score 50 - 74 / 100"
          icon={Zap}
          colorScheme="amber"
        />
        <MetricCard
          title="Available Rescue Units"
          value={metrics.availableTeams}
          subtext={`${metrics.deployedTeams} units active in field`}
          icon={Users}
          colorScheme="emerald"
          onClick={() => setCurrentView('rescue-teams')}
        />
        <MetricCard
          title="Deployed Units"
          value={metrics.deployedTeams}
          subtext="Engaged on water rescue"
          icon={Radio}
          colorScheme="cyan"
          onClick={() => setCurrentView('dispatch')}
        />
        <MetricCard
          title="Shelter Capacity"
          value={`${metrics.shelterOccupancyPercent}%`}
          subtext={`${metrics.currentShelterOccupancy} / ${metrics.totalShelterCapacity} evacuees`}
          icon={Home}
          colorScheme="blue"
          onClick={() => setCurrentView('shelters')}
        />
        <MetricCard
          title="Available ICU Beds"
          value={metrics.availableICUBeds}
          subtext={`${metrics.availableHospitalBeds} general trauma beds`}
          icon={HeartPulse}
          colorScheme="amber"
          onClick={() => setCurrentView('hospitals')}
        />
        <MetricCard
          title="River Gauges in Danger"
          value={gauges.filter((g) => g.status === 'Critical Danger').length}
          subtext="Breaching danger datum"
          icon={Activity}
          colorScheme="red"
          onClick={() => setCurrentView('live-map')}
        />
      </div>

      {/* Main Grid: Left Map (8 cols) & Right Priority Queue (4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Section: Map */}
        <div className="lg:col-span-8 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#172B3A] tracking-tight uppercase">
                Geospatial Flood Inundation & Tactical Operations Map
              </h2>
              <p className="text-xs text-slate-500">
                Real-time incident pins, water current vectors, rescue fleet telemetry, and shelter perimeters
              </p>
            </div>
            <button
              onClick={() => setCurrentView('live-map')}
              className="text-xs font-semibold text-[#0e8fa3] hover:underline flex items-center gap-1"
            >
              Full GIS View &rarr;
            </button>
          </div>

          <EmergencyMap height="460px" />
        </div>

        {/* Right Section: Priority Incident Queue & Quick Actions */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-4 flex flex-col h-[520px]">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded bg-rose-50 text-[#D9535D]">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                    AI Prioritized Incident Queue
                  </h3>
                  <span className="text-[10px] text-slate-400">
                    Sorted by automated severity score
                  </span>
                </div>
              </div>
              <span className="text-xs font-mono font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-600">
                {prioritizedIncidents.length} Active
              </span>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 pr-1 mt-2 space-y-1">
              {prioritizedIncidents.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  No unassigned or active emergencies in queue.
                </div>
              ) : (
                prioritizedIncidents.map((incident) => (
                  <div
                    key={incident.id}
                    onClick={() => setSelectedIncident(incident)}
                    className="p-3 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] text-slate-400 font-bold">
                        {incident.refNumber}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold text-[#D9535D] bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                          {incident.aiAssessment.score}/100
                        </span>
                        <SeverityBadge severity={incident.severity} size="sm" />
                      </div>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 leading-snug line-clamp-1">
                      {incident.title}
                    </h4>

                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span className="truncate max-w-[170px]">{incident.locationName}</span>
                      <span className="font-mono text-slate-700 font-medium">
                        {incident.affectedPeopleCount} people
                      </span>
                    </div>

                    <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1">
                      <span>Status: <strong className="text-slate-600">{incident.status}</strong></span>
                      <span className="text-[#36B9CA] hover:underline font-semibold flex items-center gap-0.5">
                        Inspect &rarr;
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Quick Action Buttons at bottom of card */}
            <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => setIsReportModalOpen(true)}
                className="bg-[#D9535D] hover:bg-[#c4434d] text-white py-1.5 px-2 rounded font-semibold text-center cursor-pointer transition-colors"
              >
                + New Report
              </button>
              <button
                onClick={() => setCurrentView('dispatch')}
                className="bg-[#101D2C] hover:bg-[#1B2C3D] text-white py-1.5 px-2 rounded font-semibold text-center cursor-pointer transition-colors"
              >
                Dispatch Console
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Lower Section: Analytics & River Telemetry Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Severity Distribution Donut */}
        <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-4 flex flex-col justify-between">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
              Incident Severity Breakdown
            </h3>
            <p className="text-[11px] text-slate-500">Categorized by AI priority thresholds</p>
          </div>
          <div className="h-48 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-around text-xs border-t border-slate-100 pt-2 font-mono">
            {severityData.map((d) => (
              <div key={d.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                <span className="text-slate-600">{d.name}:</span>
                <span className="font-bold text-slate-900">{d.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 24-Hour River Level Hydrograph */}
        <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-4 flex flex-col justify-between">
          <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                River Water Gauge Telemetry (Meters)
              </h3>
              <p className="text-[11px] text-slate-500">Live surge profile (Khan & Kshipra)</p>
            </div>
            <span className="text-[10px] font-mono font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">
              DANGER SURGE
            </span>
          </div>
          <div className="h-48 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={waterTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} stroke="#94A3B8" />
                <YAxis tick={{ fontSize: 10 }} stroke="#94A3B8" domain={[2, 7]} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="khanRiver"
                  name="Khan River (Indore)"
                  stroke="#D9535D"
                  fill="#D9535D"
                  fillOpacity={0.25}
                />
                <Area
                  type="monotone"
                  dataKey="kshipraRiver"
                  name="Kshipra River (Ujjain)"
                  stroke="#3478B9"
                  fill="#3478B9"
                  fillOpacity={0.15}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between text-[11px] text-slate-500 border-t border-slate-100 pt-2">
            <span>Critical Datum: 4.5m (Khan)</span>
            <span>Current: 4.85m (+0.35m)</span>
          </div>
        </div>

        {/* Recent EOC Operational Timeline */}
        <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-4 flex flex-col justify-between">
          <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                Recent Operations Log
              </h3>
              <p className="text-[11px] text-slate-500">Live system and dispatch actions</p>
            </div>
            <button
              onClick={() => setCurrentView('audit-logs')}
              className="text-[11px] text-[#0e8fa3] font-semibold hover:underline"
            >
              All Logs &rarr;
            </button>
          </div>
          <div className="divide-y divide-slate-100 overflow-y-auto max-h-48 text-xs pr-1">
            {logs.slice(0, 4).map((l) => (
              <div key={l.id} className="py-2 space-y-0.5">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-800">{l.action}</span>
                  <span className="text-[10px] font-mono text-slate-400">
                    {new Date(l.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 truncate">{l.details}</p>
                <div className="text-[10px] text-slate-400">Actor: {l.user} ({l.userRole})</div>
              </div>
            ))}
          </div>
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Audit Trail Verifier: Active</span>
            <span className="font-mono text-[#2E9D76]">SYNCHRONIZED</span>
          </div>
        </div>
      </div>
    </div>
  );
};

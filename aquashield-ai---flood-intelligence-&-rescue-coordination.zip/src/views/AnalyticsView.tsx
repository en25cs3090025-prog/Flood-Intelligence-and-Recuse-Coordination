import React from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { TrendingUp, Clock, ShieldCheck, Activity, Award } from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { incidents, shelters, teams, gauges } = useApp();

  // Hydrograph data
  const hydrographData = [
    { time: '00:00', Khan: 3.1, Kshipra: 4.8, Bilawali: 2.8, Danger: 4.5 },
    { time: '02:00', Khan: 3.3, Kshipra: 5.0, Bilawali: 2.9, Danger: 4.5 },
    { time: '04:00', Khan: 3.9, Kshipra: 5.4, Bilawali: 3.1, Danger: 4.5 },
    { time: '05:00', Khan: 4.4, Kshipra: 5.9, Bilawali: 3.3, Danger: 4.5 },
    { time: '06:00', Khan: 4.85, Kshipra: 6.2, Bilawali: 3.4, Danger: 4.5 },
    { time: '07:00', Khan: 4.95, Kshipra: 6.3, Bilawali: 3.45, Danger: 4.5 },
  ];

  // Unit response SLA benchmarks
  const agencySLAData = [
    { agency: 'NDRF Taskforce', avgDispatchMin: 7, avgOnSceneMin: 22, targetMin: 25 },
    { agency: 'SDRF Water Unit', avgDispatchMin: 9, avgOnSceneMin: 26, targetMin: 30 },
    { agency: 'Fire & Marine', avgDispatchMin: 5, avgOnSceneMin: 18, targetMin: 20 },
    { agency: 'Civil Defense', avgDispatchMin: 12, avgOnSceneMin: 34, targetMin: 35 },
    { agency: 'Medical Unit', avgDispatchMin: 6, avgOnSceneMin: 19, targetMin: 25 },
  ];

  // Shelter Occupancy Breakdown
  const shelterCapacityData = shelters.map((s) => ({
    name: s.name.split(' ')[0] + ' ' + (s.name.split(' ')[1] || ''),
    occupancy: s.currentOccupancy,
    capacity: s.totalCapacity,
    available: s.totalCapacity - s.currentOccupancy,
  }));

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Intelligence & Hydrological Analytics
          </h2>
          <p className="text-xs text-slate-500">
            Post-incident response time metrics, hydraulic telemetry surges, and resource allocation efficiency.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono bg-white px-3.5 py-1.5 rounded-lg border border-slate-200">
          <span className="flex items-center gap-1.5 text-emerald-700 font-bold">
            <Award className="w-4 h-4 text-emerald-600" />
            98.2% LIFE EXTRACTION SUCCESS
          </span>
          <span className="text-slate-300">|</span>
          <span className="text-slate-600">
            Avg Time to Dispatch: <strong>7.8 mins</strong>
          </span>
        </div>
      </div>

      {/* Top 4 Summary Metric Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Mean Dispatch Time
          </span>
          <div className="text-2xl font-bold font-mono text-[#172B3A] mt-1">7.4 min</div>
          <span className="text-[11px] text-emerald-600 font-medium mt-0.5 block">
            &darr; 2.1 min vs manual triage
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            On-Scene Arrival Time
          </span>
          <div className="text-2xl font-bold font-mono text-[#172B3A] mt-1">21.8 min</div>
          <span className="text-[11px] text-emerald-600 font-medium mt-0.5 block">
            94% within Gold Hour SLA
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Citizens Evacuated to Date
          </span>
          <div className="text-2xl font-bold font-mono text-blue-700 mt-1">1,295</div>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">
            Across 4 certified relief hubs
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            AI Triage Accuracy
          </span>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1">96.8%</div>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">
            Audited against on-scene feedback
          </span>
        </div>
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hydrograph Multi-River Hydro Curve */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div>
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                Basin Hydrograph Telemetry Comparison (Meters)
              </h3>
              <p className="text-[11px] text-slate-400">Continuous gauge river level monitoring</p>
            </div>
            <span className="text-[10px] font-mono text-rose-600 bg-rose-50 px-2 py-0.5 rounded font-bold">
              SURGE ALERT
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={hydrographData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="time" tick={{ fontSize: 11 }} stroke="#94A3B8" />
                <YAxis tick={{ fontSize: 11 }} stroke="#94A3B8" domain={[2, 7]} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line
                  type="monotone"
                  dataKey="Khan"
                  name="Khan River (Indore)"
                  stroke="#D9535D"
                  strokeWidth={2.5}
                />
                <Line
                  type="monotone"
                  dataKey="Kshipra"
                  name="Kshipra River (Ujjain)"
                  stroke="#3478B9"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="Bilawali"
                  name="Bilawali Basin"
                  stroke="#E88C43"
                  strokeWidth={1.5}
                />
                <Line
                  type="monotone"
                  dataKey="Danger"
                  name="Universal Danger Line"
                  stroke="#DC2626"
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Agency Dispatch SLA Benchmark */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div>
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                Agency Response Time Benchmark (Minutes)
              </h3>
              <p className="text-[11px] text-slate-400">Time from dispatch order to on-scene arrival</p>
            </div>
            <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold">
              SLA MET
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={agencySLAData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="agency" tick={{ fontSize: 10 }} stroke="#94A3B8" />
                <YAxis tick={{ fontSize: 11 }} stroke="#94A3B8" />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="avgDispatchMin" name="Dispatch Initiation (min)" fill="#36B9CA" />
                <Bar dataKey="avgOnSceneMin" name="On-Scene Arrival (min)" fill="#101D2C" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Shelter Capacity & Availability Stacked Bar */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3 lg:col-span-2">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div>
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                Relief Camp Capacity vs Current Occupancy Load
              </h3>
              <p className="text-[11px] text-slate-400">Distribution of available spaces for mass evacuations</p>
            </div>
            <span className="text-[10px] font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded font-bold">
              BUFFER: 1,065 CITIZENS
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={shelterCapacityData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#94A3B8" />
                <YAxis tick={{ fontSize: 11 }} stroke="#94A3B8" />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="occupancy" name="Current Occupants" fill="#D9535D" stackId="a" />
                <Bar dataKey="available" name="Available Space" fill="#2E9D76" stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

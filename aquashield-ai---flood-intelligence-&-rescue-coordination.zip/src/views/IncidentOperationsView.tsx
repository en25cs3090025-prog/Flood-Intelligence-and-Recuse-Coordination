import React, { useState, useMemo } from 'react';
import {
  AlertOctagon,
  Search,
  Filter,
  Download,
  Plus,
  ArrowUpDown,
  Sparkles,
  Users,
  MapPin,
  Clock,
  Eye,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Incident, IncidentStatus, SeverityLevel } from '../types';
import { SeverityBadge } from '../components/common/SeverityBadge';

export const IncidentOperationsView: React.FC = () => {
  const {
    incidents,
    setSelectedIncident,
    setIsReportModalOpen,
    searchQuery,
    setSearchQuery,
  } = useApp();

  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [severityFilter, setSeverityFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'risk' | 'newest' | 'casualties'>('risk');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  const filteredIncidents = useMemo(() => {
    return incidents
      .filter((inc) => {
        const query = searchQuery.toLowerCase();
        const matchesSearch =
          inc.title.toLowerCase().includes(query) ||
          inc.refNumber.toLowerCase().includes(query) ||
          inc.locationName.toLowerCase().includes(query) ||
          inc.reporterName.toLowerCase().includes(query) ||
          inc.category.toLowerCase().includes(query);

        const matchesStatus = statusFilter === 'ALL' || inc.status === statusFilter;
        const matchesSeverity = severityFilter === 'ALL' || inc.severity === severityFilter;

        return matchesSearch && matchesStatus && matchesSeverity;
      })
      .sort((a, b) => {
        if (sortBy === 'risk') return b.aiAssessment.score - a.aiAssessment.score;
        if (sortBy === 'casualties') return b.affectedPeopleCount - a.affectedPeopleCount;
        return new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime();
      });
  }, [incidents, searchQuery, statusFilter, severityFilter, sortBy]);

  const exportCSV = () => {
    const headers = [
      'Ref Number',
      'Title',
      'Category',
      'Location',
      'Status',
      'Severity',
      'AI Risk Score',
      'Affected People',
      'Assigned Unit',
      'Reported Time',
    ];
    const rows = filteredIncidents.map((i) => [
      i.refNumber,
      `"${i.title.replace(/"/g, '""')}"`,
      i.category,
      `"${i.locationName.replace(/"/g, '""')}"`,
      i.status,
      i.severity,
      i.aiAssessment.score,
      i.affectedPeopleCount,
      i.assignedTeamName || 'Unassigned',
      i.reportedAt,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `aquashield_incidents_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Top Action Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Incident Operations & Triage Registry
          </h2>
          <p className="text-xs text-slate-500">
            Real-time incident dispatch database prioritized via transparent algorithmic AI risk scoring.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={exportCSV}
            className="flex items-center gap-2 border border-slate-300 hover:bg-slate-50 text-slate-700 px-3.5 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setIsReportModalOpen(true)}
            className="flex items-center gap-2 bg-[#D9535D] hover:bg-[#c4434d] text-white px-4 py-1.5 rounded-md text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>File Emergency Report</span>
          </button>
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="bg-white p-4 rounded-lg border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          {/* Search Box */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search ref #, title, colony..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs outline-none focus:border-[#36B9CA]"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-slate-700 outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="Reported">Reported</option>
              <option value="Verified">Verified</option>
              <option value="Assigned">Assigned</option>
              <option value="Dispatched">Dispatched</option>
              <option value="On-Scene">On-Scene</option>
              <option value="Resolved">Resolved</option>
            </select>
          </div>

          {/* Severity Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium">Severity:</span>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-slate-700 outline-none"
            >
              <option value="ALL">All Severities</option>
              <option value="Critical">Critical (75+)</option>
              <option value="High">High (50-74)</option>
              <option value="Medium">Medium (25-49)</option>
              <option value="Safe">Safe (&lt;25)</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-slate-700 outline-none"
            >
              <option value="risk">AI Risk Score (High &rarr; Low)</option>
              <option value="newest">Newest Reported</option>
              <option value="casualties">Casualties Count</option>
            </select>
          </div>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center border border-slate-200 rounded overflow-hidden">
          <button
            onClick={() => setViewMode('table')}
            className={`px-3 py-1 font-semibold ${
              viewMode === 'table' ? 'bg-[#101D2C] text-white' : 'bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            Table
          </button>
          <button
            onClick={() => setViewMode('cards')}
            className={`px-3 py-1 font-semibold ${
              viewMode === 'cards' ? 'bg-[#101D2C] text-white' : 'bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            Cards
          </button>
        </div>
      </div>

      {/* Table Presentation */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#101D2C] text-slate-300 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Ref Number</th>
                  <th className="py-3 px-4">Incident Title & Category</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4 text-center">AI Risk Score</th>
                  <th className="py-3 px-4 text-center">Severity</th>
                  <th className="py-3 px-4 text-center">Casualties</th>
                  <th className="py-3 px-4">Assigned Unit</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {filteredIncidents.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-400">
                      No incidents match the specified query or filters.
                    </td>
                  </tr>
                ) : (
                  filteredIncidents.map((incident) => (
                    <tr
                      key={incident.id}
                      onClick={() => setSelectedIncident(incident)}
                      className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-slate-700">
                        {incident.refNumber}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 leading-snug max-w-xs truncate">
                          {incident.title}
                        </div>
                        <div className="text-[11px] text-slate-400">{incident.category}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 max-w-[180px] truncate">
                        {incident.locationName}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-mono font-bold text-xs bg-slate-100 text-[#172B3A] px-2 py-0.5 rounded border border-slate-200">
                          {incident.aiAssessment.score}/100
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <SeverityBadge severity={incident.severity} size="sm" />
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-slate-700">
                        {incident.affectedPeopleCount}
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        {incident.assignedTeamName ? (
                          <span className="font-semibold text-blue-700 truncate block max-w-[140px]">
                            {incident.assignedTeamName}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">Unassigned</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase bg-slate-100 text-slate-700">
                          {incident.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedIncident(incident);
                          }}
                          className="text-[#0e8fa3] font-semibold hover:underline flex items-center gap-1 ml-auto"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Inspect</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Showing {filteredIncidents.length} of {incidents.length} total incidents</span>
            <span className="font-mono text-[11px]">Sync: EOC Central DB</span>
          </div>
        </div>
      ) : (
        /* Cards Presentation */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredIncidents.map((incident) => (
            <div
              key={incident.id}
              onClick={() => setSelectedIncident(incident)}
              className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-4 hover:shadow-md hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-500">
                    {incident.refNumber}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-mono font-bold text-[#D9535D] bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                      {incident.aiAssessment.score}/100
                    </span>
                    <SeverityBadge severity={incident.severity} size="sm" />
                  </div>
                </div>

                <h3 className="font-bold text-sm text-[#172B3A] line-clamp-2">
                  {incident.title}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2">
                  {incident.description}
                </p>
              </div>

              <div className="space-y-2 text-xs pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between text-slate-600">
                  <span className="flex items-center gap-1 truncate max-w-[180px]">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {incident.locationName}
                  </span>
                  <span className="font-mono font-bold text-slate-800">
                    {incident.affectedPeopleCount} people
                  </span>
                </div>

                <div className="bg-slate-50 p-2 rounded text-[11px] text-slate-600 space-y-1">
                  <div className="flex justify-between">
                    <span>Water: <strong>{incident.waterLevel}</strong></span>
                    <span>Status: <strong>{incident.status}</strong></span>
                  </div>
                  <div className="text-blue-700 font-semibold truncate">
                    Unit: {incident.assignedTeamName || 'Standby for Dispatch'}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

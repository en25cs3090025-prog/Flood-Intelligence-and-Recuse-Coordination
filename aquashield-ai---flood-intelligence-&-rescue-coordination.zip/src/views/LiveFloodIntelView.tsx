import React, { useState } from 'react';
import {
  MapPin,
  Activity,
  Layers,
  CloudRain,
  Compass,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  Droplets,
  Wifi,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EmergencyMap } from '../components/map/EmergencyMap';

export const LiveFloodIntelView: React.FC = () => {
  const { gauges, incidents, setSelectedIncident } = useApp();
  const [selectedGaugeId, setSelectedGaugeId] = useState<string>(gauges[0]?.id || '');

  const activeGauge = gauges.find((g) => g.id === selectedGaugeId) || gauges[0];

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner: Weather & Hydrological Telemetry */}
      <div className="bg-[#101D2C] text-white p-4 rounded-xl border border-slate-700 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-500/20 text-[#36B9CA] rounded-lg border border-cyan-500/30">
            <CloudRain className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-wide">
                DOPPLER RADAR & HYDROLOGICAL SENSOR SENTINEL
              </h2>
              <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                Flash Alert
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Automated telemetry stream from 5 river sensor posts across Indore, Ujjain, Dewas & Bhopal basins.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs font-mono">
          <div className="text-right">
            <div className="text-slate-400 text-[10px]">RAINFALL ACCUMULATION</div>
            <div className="font-bold text-[#36B9CA] text-sm">68.4 mm / 3h</div>
          </div>
          <div className="text-right">
            <div className="text-slate-400 text-[10px]">CATCHMENT SATURATION</div>
            <div className="font-bold text-[#E88C43] text-sm">91% SATURATED</div>
          </div>
          <div className="text-right">
            <div className="text-slate-400 text-[10px]">TELEMETRY HEALTH</div>
            <div className="font-bold text-emerald-400 text-sm">100% PING OK</div>
          </div>
        </div>
      </div>

      {/* Main Workstation Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: River Gauge Sensor Telemetry Cards (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-lg border border-slate-200/80 p-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#3478B9]" /> River Gauge Telemetry Posts
              </h3>
              <span className="text-[10px] font-mono text-slate-400">5 ACTIVE STATIONS</span>
            </div>

            <div className="divide-y divide-slate-100 mt-2 space-y-2 max-h-[580px] overflow-y-auto pr-1">
              {gauges.map((gauge) => {
                const isDanger = gauge.status === 'Critical Danger';
                const isWarning = gauge.status === 'Warning';
                const isSelected = activeGauge.id === gauge.id;

                return (
                  <div
                    key={gauge.id}
                    onClick={() => setSelectedGaugeId(gauge.id)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-[#36B9CA] bg-cyan-50/40 shadow-xs'
                        : 'border-slate-100 hover:border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] font-bold text-slate-500">
                        {gauge.sensorCode}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          isDanger
                            ? 'bg-rose-100 text-[#D9535D]'
                            : isWarning
                            ? 'bg-amber-100 text-[#E88C43]'
                            : 'bg-emerald-100 text-[#2E9D76]'
                        }`}
                      >
                        {gauge.status.toUpperCase()}
                      </span>
                    </div>

                    <h4 className="font-bold text-xs text-slate-900 mt-1">{gauge.riverOrBasin}</h4>
                    <p className="text-[11px] text-slate-500 truncate">{gauge.stationName}</p>

                    <div className="mt-2 grid grid-cols-2 gap-2 bg-slate-50 p-2 rounded text-xs font-mono">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Current Level:</span>
                        <span
                          className={`font-bold text-sm ${
                            isDanger ? 'text-[#D9535D]' : isWarning ? 'text-[#E88C43]' : 'text-slate-800'
                          }`}
                        >
                          {gauge.currentWaterLevelMeters} m
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Danger Mark:</span>
                        <span className="font-semibold text-slate-700">{gauge.dangerLevelMeters} m</span>
                      </div>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 flex items-center gap-1">
                        <TrendingUp className="w-3.5 h-3.5 text-[#3478B9]" />
                        {gauge.trend}
                      </span>
                      <span className="text-slate-400 text-[10px]">Ping: {gauge.lastPing}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Large Interactive Map & Inundation Analysis (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white rounded-lg border border-slate-200/80 p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                  Real-Time GIS Hydraulic Inundation Map
                </h3>
                <p className="text-xs text-slate-500">
                  Focus: Khan & Kshipra River Corridors • Zoom and inspect markers & hazard perimeters
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Telemetry Live</span>
              </div>
            </div>

            <EmergencyMap height="560px" center={activeGauge.coordinates} zoom={13} />
          </div>

          {/* Road / Evacuation Corridor Status Matrix */}
          <div className="bg-white rounded-lg border border-slate-200/80 p-4 shadow-xs">
            <h4 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide mb-3">
              Primary Evacuation Corridors & Road Navigability Status
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                <div className="flex justify-between font-bold text-emerald-900">
                  <span>AB Road (Indore-Dewas)</span>
                  <span>PASSABLE</span>
                </div>
                <div className="text-[11px] text-emerald-800 mt-1">
                  Flyovers dry, heavy transit and relief supply trucks cleared.
                </div>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex justify-between font-bold text-amber-900">
                  <span>Indore - Ujjain 4-Lane Highway</span>
                  <span>RESTRICTED</span>
                </div>
                <div className="text-[11px] text-amber-800 mt-1">
                  Water crossing at Kshipra bridge approach. High-clearance vehicles only.
                </div>
              </div>

              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg">
                <div className="flex justify-between font-bold text-rose-900">
                  <span>Khandwa Road (Bilawali Spillway)</span>
                  <span>CLOSED</span>
                </div>
                <div className="text-[11px] text-rose-800 mt-1">
                  Submerged under 2.5ft fast current. Traffic diverted via Ring Road.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

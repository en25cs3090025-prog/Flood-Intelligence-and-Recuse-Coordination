import React, { useState } from 'react';
import {
  Contact,
  Phone,
  Radio,
  ShieldCheck,
  Search,
  CheckCircle2,
  Mail,
  UserCheck,
} from 'lucide-react';
import { DEMO_USERS } from '../data/seedData';

interface StaffMember {
  id: string;
  name: string;
  role: string;
  agency: string;
  callsign: string;
  phone: string;
  email: string;
  shift: 'Day Shift (On-Duty)' | 'Night Shift (Standby)' | 'Off-Duty';
  station: string;
}

const STAFF_ROSTER: StaffMember[] = [
  {
    id: 'st-01',
    name: 'Dr. Rajeshwar Sharma',
    role: 'EOC Director & State Incident Commander',
    agency: 'State Disaster Management Authority (SDMA MP)',
    callsign: 'EOC-COMMANDER-01',
    phone: '+91 98260 90001',
    email: 'admin.eoc@aquashield.org',
    shift: 'Day Shift (On-Duty)',
    station: 'State EOC Command Center, Bhopal',
  },
  {
    id: 'st-02',
    name: 'Capt. Priya Deshmukh',
    role: 'Senior Disaster Response Coordinator',
    agency: 'District Emergency Operations Center (DEOC)',
    callsign: 'OPS-LEAD-INDORE',
    phone: '+91 94250 88200',
    email: 'coordinator.ops@aquashield.org',
    shift: 'Day Shift (On-Duty)',
    station: 'Indore Collectorate Operations Room',
  },
  {
    id: 'st-03',
    name: 'Sub-Inspector Amit Verma',
    role: 'Waterborne Rescue Unit Leader',
    agency: '11th Battalion NDRF Water Rescue',
    callsign: 'NDRF-ALPHA-01',
    phone: '+91 94250 11991',
    email: 'alpha.lead@ndrf.gov.in',
    shift: 'Day Shift (On-Duty)',
    station: 'Tilak Nagar River Staging Post',
  },
  {
    id: 'st-04',
    name: 'Capt. R. K. Solanki',
    role: 'Marine Unit Commander',
    agency: 'SDRF Madhya Pradesh',
    callsign: 'SDRF-BRAVO-01',
    phone: '+91 94251 22882',
    email: 'solanki.sdrf@mp.gov.in',
    shift: 'Day Shift (On-Duty)',
    station: 'Ram Ghat Sector Post, Ujjain',
  },
  {
    id: 'st-05',
    name: 'Dr. Shalini Saxena',
    role: 'Chief Medical Triage Officer',
    agency: 'Rapid Paramedic Taskforce',
    callsign: 'PARAMEDIC-LEAD',
    phone: '+91 94240 55115',
    email: 'shalini.med@aquashield.org',
    shift: 'Day Shift (On-Duty)',
    station: 'MY Hospital Staging Camp',
  },
  {
    id: 'st-06',
    name: 'Eng. Devendra Kushwaha',
    role: 'Hydraulic Engineer & Dewatering Lead',
    agency: 'Civil Defense Heavy Pump Crew',
    callsign: 'CIVIL-DELTA-01',
    phone: '+91 98262 44664',
    email: 'devendra.cd@mp.gov.in',
    shift: 'Day Shift (On-Duty)',
    station: 'Dewas Depot',
  },
  {
    id: 'st-07',
    name: 'Officer Vikramaditya Singh',
    role: 'Geospatial Intelligence Analyst',
    agency: 'GIS Flood Mapping Unit',
    callsign: 'GIS-ANALYST-02',
    phone: '+91 98930 44551',
    email: 'gis.intel@aquashield.org',
    shift: 'Day Shift (On-Duty)',
    station: 'Central Remote Sensing Hub',
  },
];

export const PersonnelView: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStaff = STAFF_ROSTER.filter((s) => {
    const q = searchTerm.toLowerCase();
    return (
      s.name.toLowerCase().includes(q) ||
      s.role.toLowerCase().includes(q) ||
      s.agency.toLowerCase().includes(q) ||
      s.callsign.toLowerCase().includes(q) ||
      s.station.toLowerCase().includes(q)
    );
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Personnel Administration & Duty Roster
          </h2>
          <p className="text-xs text-slate-500">
            Emergency response directors, incident commanders, boat masters, and technical triage specialists.
          </p>
        </div>

        <div className="text-xs font-mono bg-white px-3 py-1.5 rounded-lg border border-slate-200">
          <span className="text-slate-400">Total Active Duty Roster: </span>
          <strong className="text-emerald-700">7 ON-DUTY COMMANDERS</strong>
        </div>
      </div>

      <div className="bg-white p-3 rounded-lg border border-slate-200/80 shadow-xs max-w-md">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search commander name, agency, callsign, or station..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs outline-none focus:border-[#36B9CA]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredStaff.map((staff) => (
          <div
            key={staff.id}
            className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:shadow-md transition-all space-y-4"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                    {staff.callsign}
                  </span>
                  <h3 className="font-bold text-sm text-[#172B3A] mt-1.5">{staff.name}</h3>
                  <div className="text-xs font-semibold text-[#0e8fa3] mt-0.5">{staff.role}</div>
                </div>

                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                  ON-DUTY
                </span>
              </div>

              <div className="mt-3 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span className="text-slate-400">Agency:</span>
                  <span className="font-semibold text-slate-800 truncate max-w-[160px]">{staff.agency}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span className="text-slate-400">Staging Station:</span>
                  <span className="font-semibold text-slate-800 truncate max-w-[160px]">{staff.station}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span className="text-slate-400">Radio VHF:</span>
                  <span className="font-mono text-blue-700 font-bold">Channel 4</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <span className="flex items-center gap-1 font-mono">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                {staff.phone}
              </span>
              <span className="flex items-center gap-1 text-[11px] text-slate-500">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                {staff.email}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

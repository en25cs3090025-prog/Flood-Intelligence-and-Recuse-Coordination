import React, { useState } from 'react';
import {
  Home,
  Users,
  Utensils,
  Droplet,
  Phone,
  Plus,
  Minus,
  CheckCircle2,
  AlertTriangle,
  Building,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Shelter } from '../types';

export const SheltersReliefView: React.FC = () => {
  const { shelters, updateShelterOccupancy } = useApp();
  const [selectedShelterId, setSelectedShelterId] = useState<string | null>(null);

  const totalCapacity = shelters.reduce((acc, s) => acc + s.totalCapacity, 0);
  const totalOccupancy = shelters.reduce((acc, s) => acc + s.currentOccupancy, 0);
  const totalWater = shelters.reduce((acc, s) => acc + s.cleanWaterLitres, 0);

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Shelters & Relief Camp Logistics Management
          </h2>
          <p className="text-xs text-slate-500">
            Real-time occupancy tracking, clean water reservoirs, ration stockpiles, and relief admissions.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono bg-white px-3.5 py-1.5 rounded-lg border border-slate-200">
          <div>
            <span className="text-slate-400">Total Capacity: </span>
            <strong className="text-slate-800">{totalOccupancy} / {totalCapacity}</strong>
          </div>
          <span className="text-slate-300">|</span>
          <div>
            <span className="text-slate-400">Potable Water: </span>
            <strong className="text-[#3478B9]">{totalWater.toLocaleString()} L</strong>
          </div>
        </div>
      </div>

      {/* Shelter Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {shelters.map((shelter) => {
          const occupancyPercent = Math.round((shelter.currentOccupancy / shelter.totalCapacity) * 100);
          const isNearFull = occupancyPercent >= 85;

          return (
            <div
              key={shelter.id}
              className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:shadow-md transition-all space-y-4"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                      CAMP SECTOR
                    </span>
                    <h3 className="font-bold text-base text-[#172B3A] mt-1">{shelter.name}</h3>
                    <p className="text-xs text-slate-500">{shelter.address}</p>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                      isNearFull
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    }`}
                  >
                    {isNearFull ? 'Near Capacity' : shelter.status}
                  </span>
                </div>

                {/* Occupancy Progress Bar */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-600 font-medium">Occupancy Load</span>
                    <span className="font-mono font-bold text-slate-800">
                      {shelter.currentOccupancy} / {shelter.totalCapacity} ({occupancyPercent}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isNearFull ? 'bg-[#D9535D]' : 'bg-[#2E9D76]'
                      }`}
                      style={{ width: `${Math.min(100, occupancyPercent)}%` }}
                    />
                  </div>
                </div>

                {/* Relief Stocks */}
                <div className="mt-4 grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
                  <div className="flex items-center gap-2">
                    <Utensils className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 block">Food Rations:</span>
                      <span className="font-mono font-bold text-slate-800">{shelter.foodRationDays} Days Buffer</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Droplet className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 block">Potable Water:</span>
                      <span className="font-mono font-bold text-slate-800">{shelter.cleanWaterLitres.toLocaleString()} Litres</span>
                    </div>
                  </div>
                </div>

                {/* Facilities Badges */}
                <div className="mt-3">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    On-Site Facilities:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {shelter.facilities.map((f, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium border border-slate-200"
                      >
                        {f}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons: Admit Evacuees */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="text-[11px] text-slate-500">
                  Officer: <strong>{shelter.contactPerson}</strong> ({shelter.phone})
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => updateShelterOccupancy(shelter.id, -10)}
                    disabled={shelter.currentOccupancy <= 0}
                    className="p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 disabled:opacity-40 cursor-pointer"
                    title="Discharge 10 evacuees"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[11px] font-mono text-slate-500">Admit:</span>
                  <button
                    onClick={() => updateShelterOccupancy(shelter.id, 10)}
                    disabled={shelter.currentOccupancy >= shelter.totalCapacity}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#101D2C] hover:bg-[#1B2C3D] text-white font-semibold cursor-pointer disabled:opacity-40"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+10</span>
                  </button>
                  <button
                    onClick={() => updateShelterOccupancy(shelter.id, 25)}
                    disabled={shelter.currentOccupancy >= shelter.totalCapacity}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-cyan-700 hover:bg-cyan-800 text-white font-semibold cursor-pointer disabled:opacity-40"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+25</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

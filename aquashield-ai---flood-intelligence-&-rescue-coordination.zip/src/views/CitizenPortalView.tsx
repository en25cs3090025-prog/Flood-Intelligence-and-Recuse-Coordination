import React, { useState } from 'react';
import {
  LifeBuoy,
  ShieldAlert,
  Search,
  Phone,
  AlertTriangle,
  CheckCircle2,
  MapPin,
  Home,
  Clock,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { Incident } from '../types';

export const CitizenPortalView: React.FC = () => {
  const { incidents, setIsReportModalOpen, shelters } = useApp();

  const [lookupRef, setLookupRef] = useState('');
  const [searchedIncident, setSearchedIncident] = useState<Incident | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lookupRef.trim()) return;

    const found = incidents.find(
      (i) => i.refNumber.toLowerCase() === lookupRef.trim().toLowerCase()
    );
    setSearchedIncident(found || null);
    setHasSearched(true);
  };

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      {/* Citizen Hero SOS Callout */}
      <div className="bg-linear-to-r from-[#101D2C] to-[#1B2C3D] text-white p-6 sm:p-8 rounded-2xl shadow-lg border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold bg-rose-500/20 text-[#D9535D] border border-rose-500/30">
            <span className="w-2 h-2 rounded-full bg-[#D9535D] animate-ping" />
            CITIZEN PUBLIC SAFETY PORTAL
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
            Stranded in Flooded Area or Need Immediate Evacuation?
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Submit your location, trapped headcount, and condition details directly to the District Emergency Operations Center (DEOC) for rapid unit dispatch.
          </p>
        </div>

        <button
          onClick={() => setIsReportModalOpen(true)}
          className="bg-[#D9535D] hover:bg-[#c4434d] text-white px-8 py-3.5 rounded-xl font-bold text-sm tracking-wide shadow-xl hover:scale-105 transition-all cursor-pointer flex items-center gap-2 shrink-0 animate-pulse"
        >
          <ShieldAlert className="w-5 h-5" />
          <span>REQUEST RESCUE NOW</span>
        </button>
      </div>

      {/* Incident Status Tracker Lookup */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-[#172B3A] uppercase tracking-wide flex items-center gap-2">
            <Search className="w-4 h-4 text-[#3478B9]" /> Track Emergency Report Status
          </h3>
          <p className="text-xs text-slate-500">
            Enter your Incident Reference ID (e.g. <strong className="font-mono text-slate-700">AQ-2026-0841</strong>) to view live rescue team dispatch status.
          </p>
        </div>

        <form onSubmit={handleLookup} className="flex gap-3 max-w-lg">
          <input
            type="text"
            value={lookupRef}
            onChange={(e) => setLookupRef(e.target.value)}
            placeholder="e.g. AQ-2026-0841"
            className="flex-1 px-4 py-2 text-xs border border-slate-200 rounded-lg font-mono uppercase focus:border-[#36B9CA] outline-none"
          />
          <button
            type="submit"
            className="bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-5 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Track Incident
          </button>
        </form>

        {hasSearched && (
          <div className="pt-2">
            {searchedIncident ? (
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-slate-800 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {searchedIncident.refNumber}
                    </span>
                    <SeverityBadge severity={searchedIncident.severity} size="sm" />
                  </div>
                  <span className="font-mono text-[10px] text-slate-400">
                    Logged: {new Date(searchedIncident.reportedAt).toLocaleTimeString()}
                  </span>
                </div>

                <h4 className="font-bold text-sm text-slate-900">{searchedIncident.title}</h4>
                <div className="text-slate-600">{searchedIncident.locationName} ({searchedIncident.address})</div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-200 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-400 block">CURRENT STATUS:</span>
                    <span className="font-bold text-blue-700 uppercase">{searchedIncident.status}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">ASSIGNED RESCUE UNIT:</span>
                    <span className="font-bold text-slate-800">
                      {searchedIncident.assignedTeamName || 'Mobilizing Team'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">AFFECTED HEADCOUNT:</span>
                    <span className="font-bold text-slate-800">{searchedIncident.affectedPeopleCount} Citizens</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">WATER LEVEL:</span>
                    <span className="font-bold text-rose-700">{searchedIncident.waterLevel}</span>
                  </div>
                </div>

                <div className="bg-white p-3 rounded-lg border border-slate-200 text-slate-700">
                  <span className="text-[#36B9CA] font-semibold">Triage Note: </span>
                  {searchedIncident.aiAssessment.explanation}
                </div>
              </div>
            ) : (
              <div className="p-4 bg-amber-50 text-amber-800 rounded-lg text-xs border border-amber-200">
                No incident matching reference "<strong>{lookupRef}</strong>" was found in current records. Please verify the ID or file a new SOS report.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Flood Safety Protocols & Nearby Shelters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Safety Directives */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-3 text-xs">
          <h3 className="font-bold text-[#172B3A] uppercase tracking-wide flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600" /> Essential Flood Safety Directives
          </h3>
          <ul className="space-y-2.5 text-slate-600">
            <li className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">1</span>
              <span><strong>Turn Around, Don't Drown:</strong> Just 6 inches of moving water can knock you down, and 12 inches can sweep away small cars. Never wade into floodwaters.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">2</span>
              <span><strong>Seek Rooftops only if Necessary:</strong> Move to upper floors immediately. If water enters your house, take dry clothes, water, and whistle. Do NOT trap yourself in closed attics without roof exits.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">3</span>
              <span><strong>Electrical Safety:</strong> Disconnect main circuit breaker before water contacts outlets. Beware of submerged distribution poles and transformer boxes.</span>
            </li>
          </ul>
        </div>

        {/* Emergency Helplines */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-3 text-xs">
          <h3 className="font-bold text-[#172B3A] uppercase tracking-wide flex items-center gap-2">
            <Phone className="w-4 h-4 text-[#3478B9]" /> 24/7 Official Emergency Helplines
          </h3>
          <div className="space-y-2">
            <div className="p-2.5 bg-slate-50 rounded-lg flex items-center justify-between border border-slate-100">
              <div>
                <div className="font-bold text-slate-800">State Disaster Control Room</div>
                <div className="text-[11px] text-slate-400">Toll-Free All MP</div>
              </div>
              <span className="font-mono font-extrabold text-sm text-[#101D2C]">1079</span>
            </div>
            <div className="p-2.5 bg-slate-50 rounded-lg flex items-center justify-between border border-slate-100">
              <div>
                <div className="font-bold text-slate-800">District Disaster Authority (DEOC)</div>
                <div className="text-[11px] text-slate-400">Indore Division Desk</div>
              </div>
              <span className="font-mono font-extrabold text-sm text-[#101D2C]">1077</span>
            </div>
            <div className="p-2.5 bg-slate-50 rounded-lg flex items-center justify-between border border-slate-100">
              <div>
                <div className="font-bold text-slate-800">National Disaster Response Force (NDRF)</div>
                <div className="text-[11px] text-slate-400">Headquarters SAR Desk</div>
              </div>
              <span className="font-mono font-extrabold text-sm text-[#101D2C]">011-24363260</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

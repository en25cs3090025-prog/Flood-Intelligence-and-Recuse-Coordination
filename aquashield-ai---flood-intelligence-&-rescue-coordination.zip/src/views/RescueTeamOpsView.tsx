import React, { useState } from 'react';
import {
  Users2,
  Phone,
  Radio,
  BatteryCharging,
  Gauge,
  Navigation,
  CheckCircle2,
  Shield,
  LifeBuoy,
  Plus,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { RescueTeam } from '../types';

export const RescueTeamOpsView: React.FC = () => {
  const { teams, setCurrentView } = useApp();
  const [filterAgency, setFilterAgency] = useState<string>('ALL');

  const filteredTeams = teams.filter(
    (t) => filterAgency === 'ALL' || t.agency === filterAgency
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Rescue Team Fleet & Field Operations (NDRF / SDRF)
          </h2>
          <p className="text-xs text-slate-500">
            Real-time status of waterborne rescue units, marine taskforces, callsigns, and gear manifests.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('dispatch')}
            className="flex items-center gap-2 bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-4 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer"
          >
            <Radio className="w-4 h-4 text-[#36B9CA]" />
            <span>Open Dispatch Room</span>
          </button>
        </div>
      </div>

      {/* Agency Filter Tabs */}
      <div className="bg-white p-3 rounded-lg border border-slate-200/80 shadow-xs flex items-center gap-2 text-xs overflow-x-auto">
        <span className="text-slate-400 font-semibold px-2 uppercase text-[11px]">Agency:</span>
        {['ALL', 'NDRF', 'SDRF', 'Fire & Marine', 'Civil Defense', 'Medical Taskforce'].map((agency) => (
          <button
            key={agency}
            onClick={() => setFilterAgency(agency)}
            className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
              filterAgency === agency
                ? 'bg-[#101D2C] text-[#36B9CA]'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            {agency}
          </button>
        ))}
      </div>

      {/* Grid of Team Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTeams.map((team) => {
          const isAvailable = team.currentStatus === 'Available';
          const isDispatched = team.currentStatus === 'Dispatched';
          const isOnScene = team.currentStatus === 'On-Scene';

          return (
            <div
              key={team.id}
              className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:shadow-md transition-all space-y-4"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                      {team.agency}
                    </span>
                    <h3 className="font-bold text-sm text-[#172B3A] mt-1.5">{team.name}</h3>
                    <div className="text-xs font-mono text-[#36B9CA] font-semibold mt-0.5">
                      Callsign: {team.callsign}
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${
                      isAvailable
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : isDispatched
                        ? 'bg-blue-50 text-blue-700 border border-blue-200 animate-pulse'
                        : isOnScene
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {team.currentStatus}
                  </span>
                </div>

                <div className="mt-3 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs space-y-1.5">
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Unit Leader:</span>
                    <span className="font-semibold text-slate-800">{team.unitLeader}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Personnel:</span>
                    <span className="font-mono font-bold text-slate-800">{team.personnelCount} Rescuers</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Location:</span>
                    <span className="truncate max-w-[170px] text-slate-700">{team.currentLocationName}</span>
                  </div>
                  {team.assignedIncidentRef && (
                    <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200">
                      <span className="text-rose-600 font-semibold">Assigned Incident:</span>
                      <span className="font-mono font-bold text-rose-700">{team.assignedIncidentRef}</span>
                    </div>
                  )}
                </div>

                {/* Equipment Badges */}
                <div className="mt-3">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Equipment Manifest:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {team.equipment.map((item, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium border border-slate-200"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Telemetry bar & Action */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 font-mono text-slate-600">
                  <BatteryCharging className="w-4 h-4 text-emerald-600" />
                  <span>{team.fuelBatteryLevel}% Battery</span>
                </div>

                <button
                  onClick={() => setCurrentView('dispatch')}
                  className="bg-[#101D2C] hover:bg-[#1B2C3D] text-white px-3 py-1 rounded text-xs font-semibold cursor-pointer transition-colors"
                >
                  Dispatch Control
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

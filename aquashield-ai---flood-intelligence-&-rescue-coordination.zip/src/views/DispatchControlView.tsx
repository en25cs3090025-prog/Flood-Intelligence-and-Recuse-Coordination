import React, { useState } from 'react';
import {
  Radio,
  Send,
  CheckCircle2,
  AlertTriangle,
  Users2,
  Navigation,
  Clock,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  Home,
  HeartPulse,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { Incident, RescueTeam } from '../types';

export const DispatchControlView: React.FC = () => {
  const {
    incidents,
    teams,
    shelters,
    hospitals,
    assignTeamToIncident,
    selectedIncident,
    setSelectedIncident,
    currentUser,
  } = useApp();

  // Active incidents needing unit assignment
  const pendingIncidents = incidents.filter(
    (i) => i.status !== 'Resolved' && i.status !== 'Closed'
  );

  const [activeIncidentId, setActiveIncidentId] = useState<string>(
    selectedIncident?.id || pendingIncidents[0]?.id || ''
  );
  const [selectedTeamId, setSelectedTeamId] = useState<string>('');
  const [targetShelterId, setTargetShelterId] = useState<string>(shelters[0]?.id || '');
  const [targetHospitalId, setTargetHospitalId] = useState<string>(hospitals[0]?.id || '');
  const [radioNote, setRadioNote] = useState('');
  const [dispatchedSuccess, setDispatchedSuccess] = useState(false);

  const currentIncident =
    incidents.find((i) => i.id === activeIncidentId) || pendingIncidents[0];

  const availableTeams = teams.filter((t) => t.currentStatus === 'Available');

  const handleDispatchOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentIncident || !selectedTeamId) {
      alert('Please select an active incident and available rescue team.');
      return;
    }

    assignTeamToIncident(
      currentIncident.id,
      selectedTeamId,
      radioNote || `Emergency Dispatch Order transmitted via EOC Radio. Designated Shelter: ${targetShelterId}`
    );

    setDispatchedSuccess(true);
    setTimeout(() => {
      setDispatchedSuccess(false);
      setSelectedTeamId('');
      setRadioNote('');
    }, 3000);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#172B3A] tracking-tight uppercase">
            Emergency Dispatch & Tactical Operations Console
          </h2>
          <p className="text-xs text-slate-500">
            Real-time unit pairing, tactical routing, radio order transmission, and destination assignment.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono bg-white px-3 py-1.5 rounded-md border border-slate-200">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-slate-600">DISPATCH CHANNEL: SECURE VHF 146.520 MHz</span>
        </div>
      </div>

      {dispatchedSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl flex items-center gap-3 text-emerald-800 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div className="text-xs">
            <span className="font-bold">DISPATCH ORDER TRANSMITTED:</span> Rescue unit mobilized. Radio acknowledgement registered in EOC operational log.
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Select Incident from Priority Queue (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3">
              <h3 className="text-xs font-bold text-[#172B3A] uppercase tracking-wide">
                Target Incident Queue ({pendingIncidents.length})
              </h3>
              <span className="text-[10px] font-mono text-slate-400">AI Priority Sorted</span>
            </div>

            <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
              {pendingIncidents.map((incident) => {
                const isSelected = incident.id === currentIncident?.id;
                return (
                  <div
                    key={incident.id}
                    onClick={() => {
                      setActiveIncidentId(incident.id);
                      setSelectedIncident(incident);
                    }}
                    className={`p-3 rounded-lg border text-xs cursor-pointer transition-all space-y-1.5 ${
                      isSelected
                        ? 'border-[#36B9CA] bg-cyan-50/40 shadow-xs'
                        : 'border-slate-100 hover:border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-slate-500 text-[10px]">
                        {incident.refNumber}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] font-bold text-[#D9535D] bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                          {incident.aiAssessment.score}/100
                        </span>
                        <SeverityBadge severity={incident.severity} size="sm" />
                      </div>
                    </div>

                    <h4 className="font-bold text-slate-900 line-clamp-1">{incident.title}</h4>
                    <p className="text-[11px] text-slate-500 truncate">{incident.locationName}</p>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                      <span>{incident.affectedPeopleCount} people</span>
                      <span className="font-semibold text-blue-700">
                        {incident.assignedTeamName ? `Assigned: ${incident.assignedTeamName}` : 'Needs Unit'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Dispatch Transmission Order Form (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {currentIncident ? (
            <form
              onSubmit={handleDispatchOrder}
              className="bg-white rounded-lg border border-slate-200/80 shadow-xs p-6 space-y-6"
            >
              {/* Incident Summary Card in Dispatch Form */}
              <div className="bg-[#101D2C] text-white p-4 rounded-xl border border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs bg-[#1B2C3D] text-[#36B9CA] px-2 py-0.5 rounded font-bold">
                      {currentIncident.refNumber}
                    </span>
                    <SeverityBadge severity={currentIncident.severity} size="sm" />
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    AI Score: <strong className="text-white">{currentIncident.aiAssessment.score}/100</strong>
                  </span>
                </div>

                <h3 className="text-base font-bold text-white">{currentIncident.title}</h3>
                <div className="text-xs text-slate-300">{currentIncident.address}</div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-700 text-xs font-mono text-slate-300">
                  <div>
                    <span className="text-slate-400 block text-[10px]">PEOPLE:</span>
                    <span className="font-bold text-white">{currentIncident.affectedPeopleCount}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">WATER LEVEL:</span>
                    <span className="font-bold text-rose-300">{currentIncident.waterLevel}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">ACCESS:</span>
                    <span className="font-bold text-cyan-300">{currentIncident.accessCondition}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">SUGGESTED CRAFT:</span>
                    <span className="font-bold text-white">{currentIncident.aiAssessment.recommendedResponse}</span>
                  </div>
                </div>
              </div>

              {/* Step 1: Select Available Unit */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Step 1: Select Optimal Rescue Unit:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {teams.map((t) => {
                    const isAvail = t.currentStatus === 'Available';
                    const isSelected = selectedTeamId === t.id;

                    return (
                      <div
                        key={t.id}
                        onClick={() => setSelectedTeamId(t.id)}
                        className={`p-3 rounded-lg border cursor-pointer transition-all ${
                          isSelected
                            ? 'border-[#36B9CA] bg-cyan-50/50 shadow-xs ring-2 ring-[#36B9CA]/30'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900">{t.name}</span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              isAvail ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                            }`}
                          >
                            {t.currentStatus}
                          </span>
                        </div>
                        <div className="text-[11px] text-[#36B9CA] font-mono mt-0.5">
                          Callsign: {t.callsign} ({t.agency})
                        </div>
                        <div className="text-[11px] text-slate-500 mt-1 truncate">
                          Equip: {t.equipment.slice(0, 2).join(', ')}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Routing Destinations (Shelter & Hospital) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                    <Home className="w-3.5 h-3.5 text-slate-500" /> Designated Evacuation Shelter:
                  </label>
                  <select
                    value={targetShelterId}
                    onChange={(e) => setTargetShelterId(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md bg-white text-slate-800"
                  >
                    {shelters.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.currentOccupancy}/{s.totalCapacity} capacity)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                    <HeartPulse className="w-3.5 h-3.5 text-slate-500" /> Designated Trauma Facility:
                  </label>
                  <select
                    value={targetHospitalId}
                    onChange={(e) => setTargetHospitalId(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md bg-white text-slate-800"
                  >
                    {hospitals.map((h) => (
                      <option key={h.id} value={h.id}>
                        {h.name} ({h.traumaIcuAvailable} ICU beds free)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Step 3: Radio Dispatch Instructions */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tactical Radio Orders / Special Access Instructions:
                </label>
                <textarea
                  rows={2}
                  value={radioNote}
                  onChange={(e) => setRadioNote(e.target.value)}
                  placeholder="e.g. Approach via Southern Embankment. Lifebuoy toss ropes required. Watch for live 11kV lines."
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md outline-none focus:border-[#36B9CA]"
                />
              </div>

              {/* Submit Dispatch Order */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                <span className="text-xs text-slate-500 font-mono">
                  Transmitting as: <strong>{currentUser.name}</strong> ({currentUser.role})
                </span>
                <button
                  type="submit"
                  disabled={!selectedTeamId}
                  className="bg-[#101D2C] hover:bg-[#1B2C3D] disabled:opacity-40 text-white px-6 py-2.5 rounded-md text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-2"
                >
                  <Radio className="w-4 h-4 text-[#36B9CA]" />
                  TRANSMIT RESCUE DISPATCH ORDER
                </button>
              </div>
            </form>
          ) : (
            <div className="bg-white p-12 text-center text-slate-400 text-xs rounded-lg border border-slate-200">
              No pending incident selected.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

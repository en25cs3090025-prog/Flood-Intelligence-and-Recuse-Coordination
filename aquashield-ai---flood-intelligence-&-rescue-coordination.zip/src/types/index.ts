export type SeverityLevel = 'Critical' | 'High' | 'Medium' | 'Safe';

export type IncidentStatus = 'Reported' | 'Verified' | 'Assigned' | 'Dispatched' | 'On-Scene' | 'Resolved' | 'Closed';

export type EmergencyCategory =
  | 'Flash Flood Rescue'
  | 'Structural Inundation'
  | 'Stranded Citizens'
  | 'Medical Emergency in Flood'
  | 'Dam / Sluice Overflow Risk'
  | 'Bridge / Road Submergence'
  | 'Power Grid Hazard'
  | 'Animal Rescue';

export type WaterLevelCondition = 'Ankle Depth (< 1ft)' | 'Knee Depth (1-2ft)' | 'Waist Depth (3-4ft)' | 'Chest Depth (5ft+)' | 'Fully Submerged / Rooftop';

export type AccessCondition = 'Normal Vehicle' | 'High-Clearance 4x4 Only' | 'Inflatable Boat / Raft Only' | 'Motorized Rescue Boat' | 'Air Evacuation Only';

export type UserRole = 'Administrator' | 'Disaster Response Coordinator' | 'Rescue Team Member' | 'Citizen';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  callsign?: string;
  agency?: string;
  avatarUrl?: string;
}

export interface RiskFactorContribution {
  name: string;
  score: number;
  maxScore: number;
  description: string;
  triggered: boolean;
}

export interface AIRiskAssessment {
  score: number; // 0 - 100
  severity: SeverityLevel;
  confidence: number; // 0 - 100%
  recommendedResponse: string;
  recommendedUnits: string[];
  factors: RiskFactorContribution[];
  explanation: string;
  assessedAt: string;
  modelVersion: string;
  aiSuggestedNotes?: string;
}

export interface Incident {
  id: string;
  refNumber: string; // e.g. "AQ-2026-0842"
  title: string;
  category: EmergencyCategory;
  description: string;
  locationName: string;
  address: string;
  coordinates: [number, number]; // [lat, lng]
  status: IncidentStatus;
  severity: SeverityLevel;
  
  // Reporter info
  reporterName: string;
  reporterPhone: string;
  reporterEmail?: string;
  isCitizenReport: boolean;
  
  // Assessment metrics
  affectedPeopleCount: number;
  childrenCount: number;
  elderlyCount: number;
  specialNeedsCount: number;
  hasMedicalUrgency: boolean;
  waterLevel: WaterLevelCondition;
  accessCondition: AccessCondition;
  immediateDanger: boolean;
  
  // Required Resources
  neededResources: string[]; // ['Rescue Boat', 'Paramedic', 'Food Rations', 'Dewatering Pump']
  
  // Risk Engine
  aiAssessment: AIRiskAssessment;
  
  // Operational assignments
  assignedTeamId?: string;
  assignedTeamName?: string;
  assignedShelterId?: string;
  assignedHospitalId?: string;
  
  reportedAt: string;
  updatedAt: string;
  resolvedAt?: string;
  timeline: {
    timestamp: string;
    action: string;
    actor: string;
    note?: string;
  }[];
}

export interface RescueTeam {
  id: string;
  name: string;
  callsign: string;
  agency: 'NDRF' | 'SDRF' | 'Civil Defense' | 'Fire & Marine' | 'Medical Taskforce';
  unitLeader: string;
  contactNumber: string;
  currentStatus: 'Available' | 'Assigned' | 'Dispatched' | 'On-Scene' | 'Standby' | 'Maintenance';
  personnelCount: number;
  equipment: string[]; // e.g. ['2x Zodiac Inflatable Boat', 'Dewatering Pump', 'Medical Kit', 'Night SAR Drone']
  currentLocationName: string;
  coordinates: [number, number];
  assignedIncidentId?: string;
  assignedIncidentRef?: string;
  fuelBatteryLevel: number; // 0 - 100%
  speedKmh?: number;
}

export interface Shelter {
  id: string;
  name: string;
  locationName: string;
  address: string;
  coordinates: [number, number];
  totalCapacity: number;
  currentOccupancy: number;
  contactPerson: string;
  phone: string;
  facilities: string[]; // e.g. ['Drinking Water', 'Hot Food', 'Dry Beds', 'Paramedic Clinic', 'Childcare']
  foodRationDays: number;
  cleanWaterLitres: number;
  status: 'Operational' | 'Full' | 'Preparing' | 'Decommissioned';
}

export interface Hospital {
  id: string;
  name: string;
  locationName: string;
  address: string;
  coordinates: [number, number];
  totalBeds: number;
  availableBeds: number;
  traumaIcuAvailable: number;
  oxygenStatus: 'Adequate' | 'Critical Low' | 'Moderate';
  ambulanceCount: number;
  availableAmbulances: number;
  contactPhone: string;
  emergencyDepartmentOpen: boolean;
}

export interface RiverGaugeSensor {
  id: string;
  sensorCode: string;
  riverOrBasin: string;
  stationName: string;
  coordinates: [number, number];
  currentWaterLevelMeters: number;
  dangerLevelMeters: number;
  warningLevelMeters: number;
  flowRateM3s: number;
  trend: 'Rising Rapidly' | 'Rising' | 'Steady' | 'Falling';
  status: 'Normal' | 'Warning' | 'Critical Danger';
  lastPing: string;
  batteryStatus: number;
}

export interface EmergencyNotification {
  id: string;
  title: string;
  message: string;
  level: 'Red Alert (Critical)' | 'Amber Alert (Warning)' | 'Yellow Alert (Watch)' | 'Informational';
  affectedZones: string[];
  issuedAt: string;
  issuedBy: string;
  status: 'Active' | 'Revoked' | 'Scheduled';
  channels: ('Public Siren' | 'SMS Blast' | 'EOC Broadcast' | 'Mobile App Notification')[];
  acknowledgedCount: number;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  category: 'Incident' | 'Dispatch' | 'AI Risk Engine' | 'System' | 'Shelter' | 'Notification';
  action: string;
  details: string;
  user: string;
  userRole: UserRole;
  relatedRef?: string;
}

export interface ScenarioSimulation {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  severity: SeverityLevel;
  waterLevelSpikeMeters: number;
  expectedNewIncidentsCount: number;
  affectedRegions: string[];
  simulatedIncidents: Partial<Incident>[];
}

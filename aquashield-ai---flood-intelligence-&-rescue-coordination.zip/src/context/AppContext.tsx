import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  ActivityLog,
  EmergencyNotification,
  Hospital,
  Incident,
  IncidentStatus,
  RescueTeam,
  RiverGaugeSensor,
  ScenarioSimulation,
  Shelter,
  UserProfile,
} from '../types';
import {
  exportSystemStateAsJSON,
  getInitialOrStoredState,
  resetAllToDefaults,
  saveStoredData,
} from '../services/storage';
import { calculateAIRiskScore } from '../services/aiRiskEngine';
import { DEMO_USERS, SIMULATION_SCENARIOS } from '../data/seedData';

export type NavigationTab =
  | 'command-center'
  | 'live-map'
  | 'incidents'
  | 'rescue-teams'
  | 'dispatch'
  | 'shelters'
  | 'hospitals'
  | 'notifications'
  | 'analytics'
  | 'simulator'
  | 'audit-logs'
  | 'personnel'
  | 'system-config'
  | 'citizen-portal';

interface CreateIncidentPayload {
  title: string;
  category: Incident['category'];
  description: string;
  locationName: string;
  address: string;
  coordinates: [number, number];
  reporterName: string;
  reporterPhone: string;
  reporterEmail?: string;
  affectedPeopleCount: number;
  childrenCount: number;
  elderlyCount: number;
  specialNeedsCount: number;
  hasMedicalUrgency: boolean;
  waterLevel: Incident['waterLevel'];
  accessCondition: Incident['accessCondition'];
  immediateDanger: boolean;
  neededResources: string[];
}

interface AppContextType {
  // State
  incidents: Incident[];
  teams: RescueTeam[];
  shelters: Shelter[];
  hospitals: Hospital[];
  gauges: RiverGaugeSensor[];
  notifications: EmergencyNotification[];
  logs: ActivityLog[];
  currentUser: UserProfile;
  currentView: NavigationTab;
  selectedIncident: Incident | null;
  isReportModalOpen: boolean;
  isAuthModalOpen: boolean;
  searchQuery: string;
  scenarios: ScenarioSimulation[];
  isSimulating: boolean;

  // Setters
  setCurrentView: (view: NavigationTab) => void;
  setSelectedIncident: (incident: Incident | null) => void;
  setIsReportModalOpen: (open: boolean) => void;
  setIsAuthModalOpen: (open: boolean) => void;
  setSearchQuery: (query: string) => void;
  switchUser: (user: UserProfile) => void;

  // Actions
  createIncident: (payload: CreateIncidentPayload) => Incident;
  updateIncidentStatus: (id: string, status: IncidentStatus, note?: string) => void;
  assignTeamToIncident: (incidentId: string, teamId: string, note?: string) => void;
  updateShelterOccupancy: (shelterId: string, countDelta: number) => void;
  createEmergencyNotification: (notif: Omit<EmergencyNotification, 'id' | 'issuedAt' | 'status' | 'acknowledgedCount'>) => void;
  revokeNotification: (id: string) => void;
  runScenarioSimulation: (scenarioId: string) => void;
  resetDemoData: () => void;
  exportJSON: () => void;

  // Computed summary metrics
  metrics: {
    totalIncidents: number;
    activeEmergencies: number;
    criticalIncidents: number;
    highIncidents: number;
    availableTeams: number;
    deployedTeams: number;
    shelterOccupancyPercent: number;
    totalShelterCapacity: number;
    currentShelterOccupancy: number;
    availableHospitalBeds: number;
    availableICUBeds: number;
    unreadNotifications: number;
  };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initialState = useMemo(() => getInitialOrStoredState(), []);

  const [incidents, setIncidents] = useState<Incident[]>(initialState.incidents);
  const [teams, setTeams] = useState<RescueTeam[]>(initialState.teams);
  const [shelters, setShelters] = useState<Shelter[]>(initialState.shelters);
  const [hospitals, setHospitals] = useState<Hospital[]>(initialState.hospitals);
  const [gauges, setGauges] = useState<RiverGaugeSensor[]>(initialState.gauges);
  const [notifications, setNotifications] = useState<EmergencyNotification[]>(initialState.notifications);
  const [logs, setLogs] = useState<ActivityLog[]>(initialState.logs);
  const [currentUser, setCurrentUser] = useState<UserProfile>(initialState.currentUser);

  const [currentView, setCurrentView] = useState<NavigationTab>('command-center');
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSimulating, setIsSimulating] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    saveStoredData('aquashield_incidents_v2', incidents);
  }, [incidents]);

  useEffect(() => {
    saveStoredData('aquashield_teams_v2', teams);
  }, [teams]);

  useEffect(() => {
    saveStoredData('aquashield_shelters_v2', shelters);
  }, [shelters]);

  useEffect(() => {
    saveStoredData('aquashield_hospitals_v2', hospitals);
  }, [hospitals]);

  useEffect(() => {
    saveStoredData('aquashield_gauges_v2', gauges);
  }, [gauges]);

  useEffect(() => {
    saveStoredData('aquashield_notifications_v2', notifications);
  }, [notifications]);

  useEffect(() => {
    saveStoredData('aquashield_logs_v2', logs);
  }, [logs]);

  useEffect(() => {
    saveStoredData('aquashield_current_user_v2', currentUser);
  }, [currentUser]);

  // Add an activity log helper
  const addLog = (
    category: ActivityLog['category'],
    action: string,
    details: string,
    relatedRef?: string
  ) => {
    const newLog: ActivityLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      category,
      action,
      details,
      user: currentUser.name,
      userRole: currentUser.role,
      relatedRef,
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  const switchUser = (user: UserProfile) => {
    setCurrentUser(user);
    addLog('System', 'User Profile Switched', `Logged in as ${user.name} (${user.role})`);
    if (user.role === 'Citizen') {
      setCurrentView('citizen-portal');
    }
  };

  const createIncident = (payload: CreateIncidentPayload): Incident => {
    const aiAssessment = calculateAIRiskScore({
      immediateDanger: payload.immediateDanger,
      affectedPeopleCount: payload.affectedPeopleCount,
      hasMedicalUrgency: payload.hasMedicalUrgency,
      childrenCount: payload.childrenCount,
      elderlyCount: payload.elderlyCount,
      specialNeedsCount: payload.specialNeedsCount,
      waterLevel: payload.waterLevel,
      accessCondition: payload.accessCondition,
    });

    const randSuffix = Math.floor(1000 + Math.random() * 9000);
    const refNumber = `AQ-2026-${randSuffix}`;
    const nowIso = new Date().toISOString();

    const newIncident: Incident = {
      id: `inc-${Date.now()}`,
      refNumber,
      title: payload.title,
      category: payload.category,
      description: payload.description,
      locationName: payload.locationName,
      address: payload.address,
      coordinates: payload.coordinates,
      status: 'Reported',
      severity: aiAssessment.severity,
      reporterName: payload.reporterName,
      reporterPhone: payload.reporterPhone,
      reporterEmail: payload.reporterEmail,
      isCitizenReport: currentUser.role === 'Citizen',
      affectedPeopleCount: payload.affectedPeopleCount,
      childrenCount: payload.childrenCount,
      elderlyCount: payload.elderlyCount,
      specialNeedsCount: payload.specialNeedsCount,
      hasMedicalUrgency: payload.hasMedicalUrgency,
      waterLevel: payload.waterLevel,
      accessCondition: payload.accessCondition,
      immediateDanger: payload.immediateDanger,
      neededResources: payload.neededResources,
      aiAssessment,
      reportedAt: nowIso,
      updatedAt: nowIso,
      timeline: [
        {
          timestamp: nowIso,
          action: 'Incident Created & Prioritized',
          actor: `${payload.reporterName} (${currentUser.role})`,
          note: `AI Initial Priority Score: ${aiAssessment.score}/100 [${aiAssessment.severity}]`,
        },
      ],
    };

    setIncidents((prev) => [newIncident, ...prev]);

    addLog(
      'Incident',
      `Emergency Incident Filed: ${refNumber}`,
      `${payload.title} at ${payload.locationName} (${aiAssessment.severity} - ${aiAssessment.score}/100)`,
      refNumber
    );

    // Auto broadcast warning if Critical
    if (aiAssessment.severity === 'Critical') {
      const alertId = `notif-${Date.now()}`;
      const critAlert: EmergencyNotification = {
        id: alertId,
        title: `CRITICAL ALERT: ${payload.title}`,
        message: `High danger flood report logged at ${payload.locationName}. Immediate caution advised for surrounding zones.`,
        level: 'Red Alert (Critical)',
        affectedZones: [payload.locationName],
        issuedAt: nowIso,
        issuedBy: 'AquaShield Automated EOC Sentinel',
        status: 'Active',
        channels: ['EOC Broadcast', 'Mobile App Notification'],
        acknowledgedCount: 1,
      };
      setNotifications((prev) => [critAlert, ...prev]);
    }

    return newIncident;
  };

  const updateIncidentStatus = (id: string, status: IncidentStatus, note?: string) => {
    const nowIso = new Date().toISOString();
    setIncidents((prev) =>
      prev.map((inc) => {
        if (inc.id !== id) return inc;
        const updatedTimeline = [
          ...inc.timeline,
          {
            timestamp: nowIso,
            action: `Status Changed to ${status}`,
            actor: `${currentUser.name} (${currentUser.role})`,
            note: note || undefined,
          },
        ];
        return {
          ...inc,
          status,
          updatedAt: nowIso,
          resolvedAt: status === 'Resolved' || status === 'Closed' ? nowIso : inc.resolvedAt,
          timeline: updatedTimeline,
        };
      })
    );

    addLog(
      'Incident',
      `Status Updated: ${status}`,
      `Incident ${id} updated to ${status}. ${note ? `Note: ${note}` : ''}`,
      id
    );
  };

  const assignTeamToIncident = (incidentId: string, teamId: string, note?: string) => {
    const targetTeam = teams.find((t) => t.id === teamId);
    if (!targetTeam) return;

    const nowIso = new Date().toISOString();

    // Update incident
    setIncidents((prev) =>
      prev.map((inc) => {
        if (inc.id !== incidentId) return inc;
        return {
          ...inc,
          assignedTeamId: teamId,
          assignedTeamName: targetTeam.name,
          status: 'Assigned',
          updatedAt: nowIso,
          timeline: [
            ...inc.timeline,
            {
              timestamp: nowIso,
              action: `Assigned Rescue Unit: ${targetTeam.name}`,
              actor: `${currentUser.name} (${currentUser.role})`,
              note: note || `Dispatched via EOC Operations Room. Equipment: ${targetTeam.equipment.join(', ')}`,
            },
          ],
        };
      })
    );

    // Update team
    setTeams((prev) =>
      prev.map((team) => {
        if (team.id !== teamId) return team;
        return {
          ...team,
          currentStatus: 'Dispatched',
          assignedIncidentId: incidentId,
          speedKmh: 35,
        };
      })
    );

    addLog(
      'Dispatch',
      `Rescue Unit Dispatched: ${targetTeam.name}`,
      `Assigned to incident ${incidentId}. Call-sign: ${targetTeam.callsign}`,
      incidentId
    );
  };

  const updateShelterOccupancy = (shelterId: string, countDelta: number) => {
    setShelters((prev) =>
      prev.map((s) => {
        if (s.id !== shelterId) return s;
        const newOccupancy = Math.max(0, Math.min(s.totalCapacity, s.currentOccupancy + countDelta));
        return {
          ...s,
          currentOccupancy: newOccupancy,
        };
      })
    );

    addLog(
      'Shelter',
      'Shelter Occupancy Adjusted',
      `Shelter ${shelterId} intake modified by ${countDelta > 0 ? `+${countDelta}` : countDelta} citizens.`
    );
  };

  const createEmergencyNotification = (
    notif: Omit<EmergencyNotification, 'id' | 'issuedAt' | 'status' | 'acknowledgedCount'>
  ) => {
    const newNotif: EmergencyNotification = {
      ...notif,
      id: `notif-${Date.now()}`,
      issuedAt: new Date().toISOString(),
      status: 'Active',
      acknowledgedCount: 0,
    };
    setNotifications((prev) => [newNotif, ...prev]);

    addLog(
      'Notification',
      `Broadcast Emergency Alert: ${notif.title}`,
      `Level: ${notif.level}. Channels: ${notif.channels.join(', ')}`
    );
  };

  const revokeNotification = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, status: 'Revoked' } : n))
    );
    addLog('Notification', 'Emergency Alert Revoked', `Notification ${id} stood down by ${currentUser.name}`);
  };

  const runScenarioSimulation = (scenarioId: string) => {
    const scenario = SIMULATION_SCENARIOS.find((s) => s.id === scenarioId);
    if (!scenario) return;

    setIsSimulating(true);

    // 1. Spike river gauges
    setGauges((prev) =>
      prev.map((g) => {
        const spike = Number((Math.random() * scenario.waterLevelSpikeMeters * 0.9 + 0.3).toFixed(2));
        const newLevel = Number((g.currentWaterLevelMeters + spike).toFixed(2));
        const isCritical = newLevel >= g.dangerLevelMeters;
        const isWarning = newLevel >= g.warningLevelMeters;
        return {
          ...g,
          currentWaterLevelMeters: newLevel,
          flowRateM3s: Math.round(g.flowRateM3s * 1.35),
          trend: 'Rising Rapidly',
          status: isCritical ? 'Critical Danger' : isWarning ? 'Warning' : 'Normal',
          lastPing: 'Simulated Surge Alert',
        };
      })
    );

    // 2. Inject simulated incidents
    const newIncs: Incident[] = scenario.simulatedIncidents.map((mockInc, idx) => {
      const now = new Date().toISOString();
      const randRef = `AQ-SIM-${Math.floor(1000 + Math.random() * 9000)}`;
      const ai = calculateAIRiskScore({
        immediateDanger: mockInc.immediateDanger ?? true,
        affectedPeopleCount: mockInc.affectedPeopleCount ?? 10,
        hasMedicalUrgency: mockInc.hasMedicalUrgency ?? false,
        childrenCount: mockInc.childrenCount ?? 2,
        elderlyCount: mockInc.elderlyCount ?? 2,
        specialNeedsCount: mockInc.specialNeedsCount ?? 0,
        waterLevel: mockInc.waterLevel ?? 'Chest Depth (5ft+)',
        accessCondition: mockInc.accessCondition ?? 'Motorized Rescue Boat',
      });

      return {
        id: `sim-inc-${Date.now()}-${idx}`,
        refNumber: randRef,
        title: `[SIMULATION] ${mockInc.title || 'Flash Flood Alert'}`,
        category: mockInc.category || 'Flash Flood Rescue',
        description: mockInc.description || 'Drill scenario simulated incident.',
        locationName: mockInc.locationName || 'Demonstration Sector',
        address: mockInc.address || 'Demonstration Address, MP',
        coordinates: mockInc.coordinates || [22.7196, 75.8577],
        status: 'Reported',
        severity: ai.severity,
        reporterName: mockInc.reporterName || 'Simulation Drill Injector',
        reporterPhone: mockInc.reporterPhone || '+91 99999 00000',
        isCitizenReport: false,
        affectedPeopleCount: mockInc.affectedPeopleCount || 10,
        childrenCount: mockInc.childrenCount || 0,
        elderlyCount: mockInc.elderlyCount || 0,
        specialNeedsCount: mockInc.specialNeedsCount || 0,
        hasMedicalUrgency: mockInc.hasMedicalUrgency || false,
        waterLevel: mockInc.waterLevel || 'Waist Depth (3-4ft)',
        accessCondition: mockInc.accessCondition || 'Motorized Rescue Boat',
        immediateDanger: mockInc.immediateDanger || true,
        neededResources: mockInc.neededResources || ['Rescue Boat', 'Lifebuoys'],
        aiAssessment: ai,
        reportedAt: now,
        updatedAt: now,
        timeline: [
          {
            timestamp: now,
            action: `Simulated Incident Injected via Scenario: ${scenario.title}`,
            actor: 'AquaShield Drill Engine',
            note: 'Fictional exercise injection for EOC stress testing.',
          },
        ],
      };
    });

    setIncidents((prev) => [...newIncs, ...prev]);

    // 3. Issue emergency alert
    const notif: EmergencyNotification = {
      id: `sim-notif-${Date.now()}`,
      title: `[DRILL SIMULATION] ${scenario.title}`,
      message: `Scenario activated: ${scenario.subtitle}. Water levels artificially surged across river telemetry basins. Respond according to Protocol Delta.`,
      level: scenario.severity === 'Critical' ? 'Red Alert (Critical)' : 'Amber Alert (Warning)',
      affectedZones: scenario.affectedRegions,
      issuedAt: new Date().toISOString(),
      issuedBy: 'Scenario Simulator Injector',
      status: 'Active',
      channels: ['EOC Broadcast', 'Mobile App Notification'],
      acknowledgedCount: 0,
    };
    setNotifications((prev) => [notif, ...prev]);

    addLog(
      'System',
      `Drill Scenario Executed: ${scenario.title}`,
      `Spiked river sensors, injected ${newIncs.length} synthetic incidents across ${scenario.affectedRegions.join(', ')}.`
    );

    setTimeout(() => {
      setIsSimulating(false);
    }, 1200);
  };

  const resetDemoData = () => {
    resetAllToDefaults();
    const fresh = getInitialOrStoredState();
    setIncidents(fresh.incidents);
    setTeams(fresh.teams);
    setShelters(fresh.shelters);
    setHospitals(fresh.hospitals);
    setGauges(fresh.gauges);
    setNotifications(fresh.notifications);
    setLogs(fresh.logs);
    setCurrentUser(DEMO_USERS[0]);
    addLog('System', 'System Restored to Fresh Demo State', 'All records, telemetry, and logs reset to seed baseline.');
  };

  const exportJSON = () => {
    exportSystemStateAsJSON({
      exportedAt: new Date().toISOString(),
      platform: 'AQUASHIELD AI EOC Platform',
      version: '2.6-Academic-Demo',
      incidents,
      teams,
      shelters,
      hospitals,
      gauges,
      notifications,
      logs,
    });
  };

  // Compute live dashboard metrics
  const metrics = useMemo(() => {
    const totalIncidents = incidents.length;
    const activeEmergencies = incidents.filter(
      (i) => i.status !== 'Resolved' && i.status !== 'Closed'
    ).length;
    const criticalIncidents = incidents.filter(
      (i) => i.severity === 'Critical' && i.status !== 'Resolved'
    ).length;
    const highIncidents = incidents.filter(
      (i) => i.severity === 'High' && i.status !== 'Resolved'
    ).length;

    const availableTeams = teams.filter((t) => t.currentStatus === 'Available').length;
    const deployedTeams = teams.filter(
      (t) => t.currentStatus === 'Dispatched' || t.currentStatus === 'On-Scene'
    ).length;

    const totalShelterCapacity = shelters.reduce((acc, s) => acc + s.totalCapacity, 0);
    const currentShelterOccupancy = shelters.reduce((acc, s) => acc + s.currentOccupancy, 0);
    const shelterOccupancyPercent = totalShelterCapacity
      ? Math.round((currentShelterOccupancy / totalShelterCapacity) * 100)
      : 0;

    const availableHospitalBeds = hospitals.reduce((acc, h) => acc + h.availableBeds, 0);
    const availableICUBeds = hospitals.reduce((acc, h) => acc + h.traumaIcuAvailable, 0);

    const unreadNotifications = notifications.filter((n) => n.status === 'Active').length;

    return {
      totalIncidents,
      activeEmergencies,
      criticalIncidents,
      highIncidents,
      availableTeams,
      deployedTeams,
      shelterOccupancyPercent,
      totalShelterCapacity,
      currentShelterOccupancy,
      availableHospitalBeds,
      availableICUBeds,
      unreadNotifications,
    };
  }, [incidents, teams, shelters, hospitals, notifications]);

  return (
    <AppContext.Provider
      value={{
        incidents,
        teams,
        shelters,
        hospitals,
        gauges,
        notifications,
        logs,
        currentUser,
        currentView,
        selectedIncident,
        isReportModalOpen,
        isAuthModalOpen,
        searchQuery,
        scenarios: SIMULATION_SCENARIOS,
        isSimulating,
        setCurrentView,
        setSelectedIncident,
        setIsReportModalOpen,
        setIsAuthModalOpen,
        setSearchQuery,
        switchUser,
        createIncident,
        updateIncidentStatus,
        assignTeamToIncident,
        updateShelterOccupancy,
        createEmergencyNotification,
        revokeNotification,
        runScenarioSimulation,
        resetDemoData,
        exportJSON,
        metrics,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
